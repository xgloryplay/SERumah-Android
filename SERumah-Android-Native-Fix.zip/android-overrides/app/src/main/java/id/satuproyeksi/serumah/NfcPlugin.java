package id.satuproyeksi.serumah;

import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.app.Activity;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.Locale;

@CapacitorPlugin(name = "Nfc")
public class NfcPlugin extends Plugin implements NfcAdapter.ReaderCallback {
    private NfcAdapter adapter;
    private boolean scanning = false;

    @PluginMethod
    public void startScanning(PluginCall call) {
        Activity activity = getActivity();
        adapter = NfcAdapter.getDefaultAdapter(activity);
        if (adapter == null) {
            call.reject("Perangkat ini tidak memiliki NFC.");
            return;
        }
        if (!adapter.isEnabled()) {
            call.reject("NFC belum diaktifkan di pengaturan Android.");
            return;
        }
        activity.runOnUiThread(() -> {
            try {
                adapter.enableReaderMode(
                    activity,
                    this,
                    NfcAdapter.FLAG_READER_NFC_A
                        | NfcAdapter.FLAG_READER_NFC_B
                        | NfcAdapter.FLAG_READER_NFC_F
                        | NfcAdapter.FLAG_READER_NFC_V
                        | NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS,
                    null
                );
                scanning = true;
                call.resolve();
            } catch (Exception e) {
                call.reject("Tidak dapat memulai pemindaian NFC: " + e.getMessage());
            }
        });
    }

    @PluginMethod
    public void stopScanning(PluginCall call) {
        stopReader();
        call.resolve();
    }

    private void stopReader() {
        Activity activity = getActivity();
        if (adapter != null && scanning && activity != null) {
            activity.runOnUiThread(() -> {
                try { adapter.disableReaderMode(activity); } catch (Exception ignored) {}
                scanning = false;
            });
        }
    }

    @Override
    public void onTagDiscovered(Tag tag) {
        byte[] id = tag.getId();
        StringBuilder hex = new StringBuilder();
        for (byte b : id) hex.append(String.format(Locale.US, "%02X", b & 0xFF));
        JSObject payload = new JSObject();
        JSObject tagData = new JSObject();
        tagData.put("id", hex.toString());
        payload.put("nfcTag", tagData);
        payload.put("id", hex.toString());
        notifyListeners("nfcEvent", payload);
    }

    @Override
    protected void handleOnPause() {
        stopReader();
        super.handleOnPause();
    }
}
