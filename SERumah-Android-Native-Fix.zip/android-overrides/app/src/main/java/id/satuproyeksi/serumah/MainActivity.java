package id.satuproyeksi.serumah;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NfcPlugin.class);
        registerPlugin(CapacitorCalendarPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
