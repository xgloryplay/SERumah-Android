package id.satuproyeksi.serumah;

import android.content.Intent;
import android.provider.CalendarContract;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "CapacitorCalendar")
public class CapacitorCalendarPlugin extends Plugin {

    // Calendar insertion is delegated to the Android calendar app.
    // This avoids requesting broad READ_CALENDAR / WRITE_CALENDAR access.
    @PluginMethod
    public void checkAllPermissions(PluginCall call) {
        JSObject result = new JSObject();
        result.put("result", "tersedia");
        call.resolve(result);
    }

    @PluginMethod
    public void checkWriteOnlyCalendarAccess(PluginCall call) {
        JSObject result = new JSObject();
        result.put("result", "tersedia");
        call.resolve(result);
    }

    @PluginMethod
    public void requestAllPermissions(PluginCall call) {
        JSObject result = new JSObject();
        result.put("result", "tersedia");
        call.resolve(result);
    }

    @PluginMethod
    public void requestWriteOnlyCalendarAccess(PluginCall call) {
        JSObject result = new JSObject();
        result.put("result", "tersedia");
        call.resolve(result);
    }

    @PluginMethod
    public void createEvent(PluginCall call) {
        String title = call.getString("title", "Agenda SERumah");
        String notes = call.getString("notes", "");
        Long startDate = call.getLong("startDate");
        Long endDate = call.getLong("endDate");
        if (startDate == null || endDate == null) {
            call.reject("Waktu mulai dan selesai agenda wajib diisi.");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_INSERT);
        intent.setData(CalendarContract.Events.CONTENT_URI);
        intent.putExtra(CalendarContract.Events.TITLE, title);
        intent.putExtra(CalendarContract.Events.DESCRIPTION, notes);
        intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startDate);
        intent.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endDate);
        try {
            getActivity().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Aplikasi kalender tidak tersedia: " + e.getMessage());
        }
    }
}
