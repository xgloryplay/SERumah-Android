# SERumah Android native feature fix

This package adds two local Capacitor 6 Android plugins expected by the current live
SERumah web app:

- `Nfc`: reads a tag's hardware UID using Android NFC reader mode and emits `nfcEvent`.
- `CapacitorCalendar`: opens Android's calendar insert screen with the agenda prefilled.

It also adds Android fine/coarse location and NFC permissions. NFC is marked optional
so devices without NFC can still install the app.

## Apply
1. Upload this ZIP to the root of `xgloryplay/SERumah-Android` as
   `SERumah-Android-Native-Fix.zip`.
2. Replace `.github/workflows/build-apk.yml` with the workflow file in this package.
3. Commit both changes and run Actions > Build SERumah Android APK.

The existing `package.json` should remain unchanged. Do not add the nonexistent
`@capacitor/nfc` or `@capgo/capacitor-nfc` dependency.

Notes:
- Location permissions are declared at build time; the existing web UI still requests
  runtime location permission through `@capacitor/geolocation`.
- Calendar uses Android's insert intent. The user confirms/saves the event in the
  calendar app; no broad calendar read/write permission is requested.
- NFC reads UID only. It does not read stored value, balance, or transaction data.
- This package has not been compiled on a physical Android device in this environment.
  Validate the generated APK with GitHub Actions and test on an NFC-capable device.
