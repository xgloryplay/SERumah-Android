#!/usr/bin/env python3
import sys
from pathlib import Path
import xml.etree.ElementTree as ET

manifest = Path(sys.argv[1])
ET.register_namespace("android", "http://schemas.android.com/apk/res/android")
android = "{http://schemas.android.com/apk/res/android}"
tree = ET.parse(manifest)
root = tree.getroot()

required = [
    "android.permission.ACCESS_COARSE_LOCATION",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.NFC",
]
existing = {node.get(android + "name") for node in root.findall("uses-permission")}
for name in required:
    if name not in existing:
        node = ET.Element("uses-permission")
        node.set(android + "name", name)
        root.insert(0, node)

# NFC hardware is optional; app remains installable on devices without NFC.
feature_name = "android.hardware.nfc"
features = root.findall("uses-feature")
feature = next((x for x in features if x.get(android + "name") == feature_name), None)
if feature is None:
    feature = ET.Element("uses-feature")
    feature.set(android + "name", feature_name)
    root.insert(0, feature)
feature.set(android + "required", "false")

tree.write(manifest, encoding="utf-8", xml_declaration=True)
print("SERumah: location and NFC permissions configured.")
