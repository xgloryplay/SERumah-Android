SERumah - aplikasi keluarga (PHP + SQLite)
==========================================

KEBUTUHAN SERVER (cPanel)
- PHP 8.1 atau lebih baru
- Ekstensi: pdo_sqlite, mbstring, curl, json (biasanya sudah aktif)
- HTTPS aktif (AutoSSL / Let's Encrypt). Login tidak aman tanpa HTTPS.

INSTALASI
1. Upload seluruh isi folder ini ke public_html/serumah/ (atau subdomain, mis. keuangan.domainmu.com).
2. Pastikan folder "data/" bisa ditulis PHP (izin 750 atau 755 tergantung hosting).
   Database serumah.sqlite dibuat otomatis saat pertama dibuka.
3. Buka https://domainmu.com/serumah/ lalu login:
      username: serumah
      password: serumah
4. SEGERA ganti password: menu Lainnya > Pengaturan > Ganti password.

KEAMANAN
- Folder includes/ dan data/ diblokir lewat .htaccess (tidak bisa diunduh dari browser).
- Password disimpan sebagai hash (password_hash), tidak pernah plaintext.
- Setiap permintaan perubahan wajib membawa token CSRF.
- Login dibatasi 5 percobaan gagal per 15 menit per IP.
- Query selalu memakai prepared statement; kolom yang boleh diubah dibatasi whitelist.
- Cookie sesi: HttpOnly, Secure (di HTTPS), SameSite=Strict. Sesi berakhir setelah 8 jam tidak aktif.
- Header keamanan: Content-Security-Policy, X-Frame-Options, X-Content-Type-Options, Referrer-Policy.
- Backup: unduh file data/serumah.sqlite secara berkala lewat File Manager cPanel. Jangan dibagikan.

IMPORT DARI MONEYNEST
- Menu Lainnya > Import MoneyNest. Terima file .sqlite / .db / .json / .csv.
- Pilih "Pratinjau" dulu untuk melihat tabel dan kolom yang terdeteksi (tidak menyimpan apa pun).
- Kalau ada kolom yang ditandai "belum dipakai", kirim output skema (.schema) ke pengembang untuk pemetaan yang tepat.
- Saldo wallet disesuaikan agar cocok dengan saldo di MoneyNest.

CUACA
- Default Pontianak (dari Open-Meteo, gratis, tanpa API key). Ganti lokasi di Lainnya > Pengaturan.
- Hasil disimpan di cache data/ selama 30 menit.

UPDATE SKEMA
- Skema versi dikelola lewat PRAGMA user_version di includes/bootstrap.php (fungsi migrate).
  Tambahkan blok "if ($version < 2) { ... }" untuk perubahan berikutnya; jangan mengubah SCHEMA_SQL lama.
