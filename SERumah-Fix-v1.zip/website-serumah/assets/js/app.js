(() => {
'use strict';

/* ---------- utilitas ---------- */
const $ = (s, r = document) => r.querySelector(s);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const BL = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const HARI = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const today = () => ymd(new Date());
const pd = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const dl = (s) => Math.round((pd(s) - pd(today())) / 864e5);
const fdate = (s) => { const x = pd(s); return `${x.getDate()} ${BL[x.getMonth()].slice(0, 3)}`; };
const rp = (n) => (Number(n) < 0 ? '-' : '') + 'Rp ' + Math.abs(Math.round(Number(n) || 0)).toLocaleString('id-ID');
const gr = (g) => Math.round(Number(g) || 0).toLocaleString('id-ID') + ' gr';
const num = (v) => Number(v) || 0;
const sumBy = (arr, fn) => arr.reduce((a, x) => a + fn(x), 0);
const shiftMonth = (ym, d) => { const [y, m] = ym.split('-').map(Number); const x = new Date(y, m - 1 + d, 1); return `${x.getFullYear()}-${pad(x.getMonth() + 1)}`; };
const monthName = (ym) => { const [y, m] = ym.split('-').map(Number); return `${BL[m - 1]} ${y}`; };

const ICON = {
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  share: '<path d="M12 3v12M7 8l5-5 5 5M5 14v5h14v-5"/>',
  home: '<path d="M3 11l9-7 9 7v8a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  wallet: '<rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18M16 14h2"/>',
  cal: '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  shop: '<path d="M4 9h16l-1 11H5z"/><path d="M8 9V6a4 4 0 0 1 8 0v3"/>',
  dots: '<circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/>',
  tool: '<path d="M14 6a4 4 0 0 0 4 4l-8 8a2 2 0 1 1-3-3l8-8a4 4 0 0 0-1-1z"/>',
  book: '<path d="M4 4h6a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4zM20 4h-6a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h7z"/>',
  chart: '<path d="M4 20V4M4 20h16M8 16v-5M12 16V8M16 16v-3"/>',
  box: '<path d="M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h10"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  cloud: '<path d="M7 18a4 4 0 0 1 0-8 5 5 0 0 1 9.6-1A4 4 0 0 1 17 18z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',
  rain: '<path d="M7 14a4 4 0 0 1 0-8 5 5 0 0 1 9.6-1A4 4 0 0 1 17 14"/><path d="M8 17l-1 3M12 17l-1 3M16 17l-1 3"/>',
  storm: '<path d="M7 14a4 4 0 0 1 0-8 5 5 0 0 1 9.6-1A4 4 0 0 1 17 14"/><path d="M12 14l-2 4h3l-2 4"/>',
  snow: '<path d="M7 14a4 4 0 0 1 0-8 5 5 0 0 1 9.6-1A4 4 0 0 1 17 14"/><path d="M8 18h.01M12 19h.01M16 18h.01"/>',
  fog: '<path d="M4 9h16M6 13h12M4 17h16"/>',
  target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1"/>',
  car: '<path d="M4 14l2-5h12l2 5v4H4z"/><circle cx="7.5" cy="17.5" r="1.5"/><circle cx="16.5" cy="17.5" r="1.5"/>',
  repeat: '<path d="M4 12a8 8 0 0 1 14-5l2-2v6h-6l2.5-2.5A5.5 5.5 0 0 0 6.5 12"/><path d="M20 12a8 8 0 0 1-14 5l-2 2v-6h6l-2.5 2.5A5.5 5.5 0 0 0 17.5 12"/>',
  debt: '<path d="M12 2v20M17 6H9.5a2.5 2.5 0 0 0 0 5h5a2.5 2.5 0 0 1 0 5H6"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2"/>',
  import: '<path d="M12 3v12M7 10l5 5 5-5M4 20h16"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  down: '<path d="M6 9l6 6 6-6"/>',
  up: '<path d="M18 15l-6-6-6 6"/>',
  down2: '<path d="M7 7l10 10M17 7L7 17"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  pin: '<path d="M12 21s-7-6-7-11a7 7 0 0 1 14 0c0 5-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>',
};
const ic = (k, s = 22) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[k] || ''}</svg>`;

const FORMS = {
  wallets: { t: 'Wallet', f: [
    { k: 'name', l: 'Nama', req: 1 },
    { k: 'type', l: 'Jenis', sel: [['tunai', 'Tunai'], ['bank', 'Bank'], ['ewallet', 'E-wallet'], ['emoney', 'E-money (saldo diisi manual)'], ['lainnya', 'Lainnya']] },
    { k: 'start_balance', l: 'Saldo awal (Rp)', n: 1 },
    { k: 'card_uid', l: 'UID kartu NFC (diisi lewat tombol Kaitkan NFC)' } ] },
  categories: { t: 'Kategori', f: [
    { k: 'name', l: 'Nama', req: 1 },
    { k: 'kind', l: 'Berlaku untuk', sel: [['out', 'Pengeluaran'], ['in', 'Pemasukan'], ['both', 'Keduanya']] },
    { k: 'budget', l: 'Anggaran per bulan (Rp, 0 = tanpa batas)', n: 1 } ] },
  transactions: { t: 'Transaksi', f: [
    { k: 'type', l: 'Jenis', sel: [['out', 'Pengeluaran'], ['in', 'Pemasukan'], ['transfer', 'Transfer']], def: 'out' },
    { k: 'date', l: 'Tanggal', d: 1, req: 1, def: 'today' },
    { k: 'title', l: 'Keterangan', req: 1 },
    { k: 'amount', l: 'Nominal (Rp)', n: 1, req: 1 },
    { k: 'wallet_id', l: 'Dari wallet', sel: 'wallets' },
    { k: 'to_wallet_id', l: 'Ke wallet (khusus transfer)', sel: 'wallets' },
    { k: 'category_id', l: 'Kategori', sel: 'categories' },
    { k: 'note', l: 'Catatan', ta: 1 } ] },
  recurring: { t: 'Transaksi rutin', f: [
    { k: 'title', l: 'Nama', req: 1 },
    { k: 'type', l: 'Jenis', sel: [['out', 'Pengeluaran'], ['in', 'Pemasukan']], def: 'out' },
    { k: 'amount', l: 'Nominal (Rp)', n: 1, req: 1 },
    { k: 'frequency', l: 'Frekuensi', sel: [['monthly', 'Bulanan'], ['weekly', 'Mingguan']], def: 'monthly' },
    { k: 'next_date', l: 'Jatuh tempo berikutnya', d: 1, req: 1, def: 'today' },
    { k: 'wallet_id', l: 'Wallet', sel: 'wallets' },
    { k: 'category_id', l: 'Kategori', sel: 'categories' },
    { k: 'active', l: 'Aktif', bool: 1, def: 1 } ] },
  debts: { t: 'Utang / piutang', f: [
    { k: 'kind', l: 'Jenis', sel: [['utang', 'Utang (saya yang berutang)'], ['piutang', 'Piutang (orang berutang ke saya)']], def: 'utang' },
    { k: 'party', l: 'Nama pihak', req: 1 },
    { k: 'amount', l: 'Jumlah (Rp)', n: 1, req: 1 },
    { k: 'due_date', l: 'Jatuh tempo', d: 1 },
    { k: 'note', l: 'Catatan', ta: 1 } ] },
  goals: { t: 'Goal', f: [
    { k: 'name', l: 'Nama goal', req: 1 },
    { k: 'target', l: 'Target (Rp)', n: 1, req: 1 },
    { k: 'due_date', l: 'Target tanggal', d: 1 } ] },
  assets: { t: 'Aset', f: [
    { k: 'name', l: 'Nama', req: 1 },
    { k: 'type', l: 'Jenis', sel: [['saham', 'Saham'], ['reksadana', 'Reksa dana'], ['emas', 'Emas'], ['properti', 'Properti'], ['kendaraan', 'Kendaraan'], ['lainnya', 'Lainnya']], def: 'lainnya' },
    { k: 'qty', l: 'Jumlah / unit', n: 1, def: 1 },
    { k: 'buy_price', l: 'Harga beli per unit (Rp)', n: 1 },
    { k: 'current_price', l: 'Harga sekarang per unit (Rp)', n: 1 },
    { k: 'date_bought', l: 'Tanggal beli', d: 1 },
    { k: 'note', l: 'Catatan', ta: 1 } ] },
  agenda: { t: 'Agenda', f: [
    { k: 'title', l: 'Judul', req: 1 },
    { k: 'date', l: 'Tanggal', d: 1, req: 1, def: 'today' },
    { k: 'kind', l: 'Jenis', sel: [['tugas', 'Tugas'], ['tagihan', 'Tagihan']], def: 'tugas' },
    { k: 'category', l: 'Kategori (mis. Maintenance)' },
    { k: 'amount', l: 'Nominal (Rp, opsional)', n: 1 },
    { k: 'time', l: 'Jam pengingat (opsional)', t: 1 },
    { k: 'note', l: 'Catatan', ta: 1 } ] },
  journal: { t: 'Catatan jurnal', f: [
    { k: 'date', l: 'Tanggal', d: 1, req: 1, def: 'today' },
    { k: 'text', l: 'Isi catatan', ta: 1, req: 1 } ] },
  customers: { t: 'Pelanggan', f: [
    { k: 'name', l: 'Nama', req: 1 },
    { k: 'phone', l: 'No. HP / WA' },
    { k: 'address', l: 'Alamat', ta: 1 },
    { k: 'note', l: 'Catatan', ta: 1 } ] },
  pos_products: { t: 'Menu', f: [] },
};
const TABLE_OF = { customers: 'customers', wallets: 'wallets', categories: 'categories', transactions: 'transactions', recurring: 'recurring', debts: 'debts', goals: 'goals', assets: 'assets', agenda: 'agenda', journal: 'journal' };

/* ---------- state & api ---------- */
const st = { csrf: '', user: null, D: null, W: null, tab: 'home', sub: '', month: ymd(new Date()).slice(0, 7), day: null, cart: {}, rd: null, sale: null, importRes: null };

async function api(action, o = {}) {
  const headers = { 'X-CSRF-Token': st.csrf };
  let body;
  let method = 'GET';
  if (o.form) { body = o.form; method = 'POST'; }
  else if (o.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(o.json); method = 'POST'; }
  const url = `api.php?a=${encodeURIComponent(action)}` + (o.q !== undefined ? `&q=${encodeURIComponent(o.q)}` : '') + (o.extra || '');
  const r = await fetch(url, { method, headers, body, credentials: 'same-origin' });
  let j = {};
  try { j = await r.json(); } catch (_) { /* bukan JSON */ }
  if (r.status === 401 && action !== 'auth.login') { st.user = null; renderLogin(); }
  if (!r.ok) throw new Error(j.error || 'Terjadi kesalahan, coba lagi');
  return j;
}

/* ---------- tema ---------- */
const mq = window.matchMedia('(prefers-color-scheme: dark)');
function applyTheme(pref) {
  const p = pref || 'auto';
  const resolved = p === 'auto' ? (mq.matches ? 'dark' : 'light') : p;
  document.documentElement.dataset.theme = resolved;
  document.documentElement.dataset.pref = p;
}
mq.addEventListener('change', () => { if (document.documentElement.dataset.pref === 'auto') applyTheme('auto'); });

/* ---------- helper data ---------- */
const ING = (id) => st.D.pos_ingredients.find((x) => x.id == id);
const PRD = (id) => st.D.pos_products.find((x) => x.id == id);
const avgCost = (i) => (i && num(i.total_g) > 0 ? num(i.total_cost) / num(i.total_g) : 0);
const hppOf = (pid) => st.D.pos_recipes.filter((r) => r.product_id == pid).reduce((a, r) => a + avgCost(ING(r.ingredient_id)) * num(r.grams), 0);
const hasRecipe = (pid) => st.D.pos_recipes.some((r) => r.product_id == pid);
const maxMake = (pid) => {
  const rs = st.D.pos_recipes.filter((r) => r.product_id == pid);
  if (!rs.length) return 999;
  return Math.max(0, Math.min(...rs.map((r) => Math.floor(num(ING(r.ingredient_id)?.stock_g) / num(r.grams)))));
};
const cartTotal = () => Object.keys(st.cart).reduce((a, id) => a + num(PRD(id)?.price) * st.cart[id], 0);
const monthTx = (ym) => st.D.transactions.filter((t) => t.date.startsWith(ym));
const walletName = (id) => st.D.wallets.find((w) => w.id == id)?.name || '';
const catName = (id) => st.D.categories.find((c) => c.id == id)?.name || '';
function netWorth() {
  const harta = sumBy(st.D.wallets, (w) => num(w.balance)) + sumBy(st.D.assets, (a) => num(a.value));
  const left = (d) => Math.max(0, num(d.amount) - num(d.paid));
  const utang = sumBy(st.D.debts.filter((d) => d.kind === 'utang'), left);
  const piutang = sumBy(st.D.debts.filter((d) => d.kind === 'piutang'), left);
  return { harta, utang, piutang, nett: harta + piutang - utang };
}
const bar = (pct, cls = '') => `<div class="bar ${cls}"><i style="width:${Math.min(100, Math.max(0, pct)).toFixed(1)}%"></i></div>`;
const glass = (html, cls = '') => `<section class="glass ${cls}">${html}</section>`;
const sec = (title, right = '') => `<div class="sec-head"><h2>${esc(title)}</h2>${right}</div>`;
const walletOpts = (sel = '') => st.D.wallets.map((w) => `<option value="${w.id}" ${String(w.id) === String(sel) ? 'selected' : ''}>${esc(w.name)}</option>`).join('');

/* ---------- render ---------- */
function render() {
  if (!st.user) return renderLogin();
  const pages = { home: pageHome, fin: pageFin, cal: pageCal, pos: pagePos, more: pageMore };
  const navs = [['home', 'home', 'Beranda'], ['fin', 'wallet', 'Keuangan'], ['cal', 'cal', 'Kalender'], ['pos', 'shop', 'ES Factory'], ['more', 'dots', 'Lainnya']];
  const showFab = !(st.tab === 'pos' && (st.sub || 'kasir') === 'kasir');
  $('#app').innerHTML = `
    <header class="top">${brandHtml()}</header>
    <main>${pages[st.tab]()}</main>
    ${showFab ? `<button class="fab" data-act="add" aria-label="Tambah">${ic('plus', 24)}</button>` : ''}
    <nav class="bottom">${navs.map(([k, i, l]) => `<button class="${st.tab === k ? 'on' : ''}" data-act="go" data-tab="${k}">${ic(i, 22)}<span>${l}</span></button>`).join('')}</nav>
    <div id="sheet"><div id="sb"></div></div>`;
  if (st.tab === 'more' && st.sub === 'perms') refreshPermStatus();
}
function renderLogin() {
  st.user = null;
  $('#app').innerHTML = `<div class="login-wrap"><form class="glass login-card" data-submit="login" autocomplete="on">
    <div class="brand-lg"><span class="logo lg">SR</span><h1>SERumah</h1><p>Masuk untuk melanjutkan</p></div>
    <label>Username<input name="username" autocomplete="username" required maxlength="60"></label>
    <label>Password<input name="password" type="password" autocomplete="current-password" required maxlength="200"></label>
    <p class="err" id="loginErr"></p>
    <button class="btn" type="submit">Masuk</button></form></div>`;
}
function go(tab, sub = '') { st.tab = tab; st.sub = sub; render(); window.scrollTo(0, 0); }
function sheet(html) { $('#sb').innerHTML = html; $('#sheet').classList.add('o'); }
function closeSheet() { $('#sheet')?.classList.remove('o'); }
function toast(msg) {
  let t = $('#toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
  t.textContent = msg; t.classList.add('o');
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('o'), 2200);
}
async function refresh() {
  const wx = st.loc ? api('weather', { extra: `&lat=${st.loc.lat}&lon=${st.loc.lon}` }) : api('weather');
  const [d, w] = await Promise.all([api('data.all'), wx.catch(() => null)]);
  st.D = d; st.W = w;
  applyTheme(d.settings.theme || 'auto');
  applyAppearance(d.settings);
  render();
  scheduleReminders();
}

/* ---------- cuaca ---------- */
function wxCard() {
  if (!st.W) return glass(`<div class="wx-empty">${ic('cloud', 28)}<div><b>Cuaca belum tersedia</b><small>Izinkan lokasi atau atur kota di pengaturan</small></div><button class="chip" data-act="locate">Lokasi saya</button></div>`, 'wx');
  const c = st.W.data.current;
  const days = st.W.data.daily.slice(0, 5).map((d) => `<div class="wx-day"><small>${HARI[pd(d.date).getDay()]}</small>${ic(d.icon, 20)}<span>${d.max}°<em>${d.min}°</em></span></div>`).join('');
  return glass(`<div class="wx-top"><div class="wx-now"><span class="wx-ico ${esc(c.icon)}">${ic(c.icon, 46)}</span><div><b class="wx-temp">${c.temp}°</b><small>${esc(c.label)} · ${esc(st.W.name)}</small></div></div>
    <div class="wx-meta"><span>Terasa ${c.feels}°</span><span>Lembap ${c.humidity}%</span><span>Angin ${c.wind} km/j</span></div></div>
    <div class="wx-days">${days}</div>${st.loc ? '' : '<div class="btn-row"><button class="chip" data-act="locate">Aktifkan lokasi saya</button></div>'}`, 'wx');
}

/* ---------- Beranda ---------- */
const agendaRow = (a) => `<div class="li ${a.done ? 'done' : ''}">
  <button class="chk ${a.done ? 'on' : ''}" data-act="toggle" data-id="${a.id}" aria-label="Tandai selesai">${a.done ? ic('check', 14) : ''}</button>
  <div class="g" data-act="edit" data-entity="agenda" data-id="${a.id}"><b>${esc(a.title)}</b><small>${esc(a.category || (a.kind === 'tagihan' ? 'Tagihan' : 'Tugas'))}${a.time ? ' · jam ' + esc(a.time) : ''}${num(a.amount) ? ' · ' + rp(a.amount) : ''}</small></div></div>`;

function pageHome() {
  const t = today(), h = new Date().getHours(), n = new Date();
  const sap = h < 11 ? 'pagi' : h < 15 ? 'siang' : h < 18 ? 'sore' : 'malam';
  const nw = netWorth(), mt = monthTx(today().slice(0, 7));
  const inc = sumBy(mt.filter((x) => x.type === 'in'), (x) => num(x.amount));
  const out = sumBy(mt.filter((x) => x.type === 'out'), (x) => num(x.amount));
  const ag = st.D.agenda.filter((a) => a.date === t);
  const up = st.D.agenda.filter((a) => !a.done && a.date > t).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 4);
  const dueD = st.D.debts.filter((d) => d.due_date && num(d.amount) - num(d.paid) > 0 && dl(d.due_date) <= 14);
  const ts = st.D.pos_sales.filter((s) => ymd(new Date(s.ts * 1000)) === t);
  const omzet = sumBy(ts, (s) => num(s.total));
  const shortcuts = [['Keuangan', 'wallet', 'fin', ''], ['Kalender', 'cal', 'cal', ''], ['Maintenance', 'tool', 'more', 'maint'], ['ES Factory', 'shop', 'pos', 'kasir'], ['Dashboard', 'chart', 'pos', 'dash'], ['Stok', 'box', 'pos', 'stok'], ['Utang', 'debt', 'fin', 'utang'], ['Jurnal', 'book', 'more', 'journal']]
    .map(([l, i, tb, sb]) => `<button class="sc" data-act="go" data-tab="${tb}" data-sub="${sb}"><span class="ic-tile">${ic(i, 22)}</span><small>${l}</small></button>`).join('');
  return `
  <section class="glass hero"><div><small>Selamat ${sap}</small><h1>${esc(st.D.settings.family_name)}</h1><p>${HARI[n.getDay()]}, ${n.getDate()} ${BL[n.getMonth()]} ${n.getFullYear()}</p></div>
    <div class="nett"><small>Kekayaan bersih</small><b>${rp(nw.nett)}</b></div></section>
  ${wxCard()}
  <div class="duo">
    <div class="glass mini"><small>Masuk bulan ini</small><b class="in">${rp(inc)}</b></div>
    <div class="glass mini"><small>Keluar bulan ini</small><b class="out">${rp(out)}</b></div>
  </div>
  <div class="glass grid8">${shortcuts}</div>
  ${glass(`<div class="row-between"><h3>Agenda hari ini</h3><span class="pill">${ag.filter((a) => a.done).length}/${ag.length} selesai</span></div>
    ${ag.map(agendaRow).join('') || '<p class="empty">Tidak ada agenda hari ini.</p>'}
    <button class="btn ghost" data-act="new" data-entity="agenda">+ Tambah agenda</button>`)}
  ${glass(`<h3>Akan jatuh tempo</h3>
    ${up.map((a) => `<div class="li"><div class="g"><b>${esc(a.title)}</b><small>${esc(a.category || 'Agenda')} · ${fdate(a.date)}</small></div><span class="pill ${dl(a.date) <= 3 ? 'warn' : ''}">${dl(a.date)} hari</span></div>`).join('')}
    ${dueD.map((d) => `<div class="li"><div class="g"><b>${d.kind === 'utang' ? 'Utang' : 'Piutang'}: ${esc(d.party)}</b><small>${rp(num(d.amount) - num(d.paid))} sisa</small></div><span class="pill ${dl(d.due_date) <= 3 ? 'warn' : ''}">${dl(d.due_date)} hari</span></div>`).join('')}
    ${!up.length && !dueD.length ? '<p class="empty">Semuanya aman.</p>' : ''}`)}
  ${glass(`<div class="row-between"><div><h3>${esc(st.D.settings.pos_name)} hari ini</h3><small class="muted">${ts.length} transaksi</small></div><button class="chip" data-act="go" data-tab="pos" data-sub="kasir">Buka kasir</button></div>
    <div class="stat" style="margin-top:12px"><div><small>Omzet</small><b>${rp(omzet)}</b></div><div><small>Laba kotor</small><b class="in">${rp(omzet - sumBy(ts, (s) => num(s.hpp)))}</b></div></div>`)}`;
}

/* ---------- Keuangan ---------- */
const FIN_TABS = [['transaksi', 'Transaksi'], ['utang', 'Utang Piutang'], ['anggaran', 'Anggaran'], ['goal', 'Goal'], ['aset', 'Aset'], ['rutin', 'Rutin'], ['wallet', 'Wallet'], ['emoney', 'E-money'], ['alloc', 'Alokasi'], ['laporan', 'Laporan']];
function pageFin() {
  const s = st.sub || 'transaksi';
  const nw = netWorth();
  const chips = `<div class="chips">${FIN_TABS.map(([k, l]) => `<button class="chip ${s === k ? 'on' : ''}" data-act="go" data-tab="fin" data-sub="${k}">${l}</button>`).join('')}</div>`;
  const neraca = glass(`<small class="muted">Kekayaan bersih</small><div class="big">${rp(nw.nett)}</div>
    <div class="stat"><div><small>Harta (wallet + aset)</small><b>${rp(nw.harta)}</b></div><div><small>Utang</small><b class="out">${rp(nw.utang)}</b></div></div>
    <p class="muted small" style="margin:10px 0 0">Piutang yang belum kembali: ${rp(nw.piutang)}</p>`, 'neraca');
  const body = { transaksi: finTx, utang: finDebt, anggaran: finBudget, goal: finGoal, aset: finAsset, rutin: finRecurring, wallet: finWallet, emoney: finEmoney, alloc: finAlokasi, laporan: finReport }[s]();
  return `<h2 class="page-title">Keuangan</h2>${neraca}${chips}${body}`;
}
function txRow(t) {
  const cls = t.type === 'in' ? 'in' : t.type === 'out' ? 'out' : '';
  const sign = t.type === 'in' ? '+' : t.type === 'out' ? '-' : '⇄';
  const meta = t.type === 'transfer' ? `${walletName(t.wallet_id)} → ${walletName(t.to_wallet_id)}` : `${catName(t.category_id) || 'Tanpa kategori'} · ${walletName(t.wallet_id) || '-'}`;
  return `<div class="li"><span class="tx-ic ${cls}">${ic(t.type === 'in' ? 'plus' : t.type === 'out' ? 'down2' : 'repeat', 16)}</span>
    <div class="g" data-act="edit" data-entity="transactions" data-id="${t.id}"><b>${esc(t.title)}</b><small>${fdate(t.date)} · ${esc(meta)}</small></div>
    <b class="${cls}">${sign}${rp(t.amount)}</b></div>`;
}
function finTx() {
  return sec('Transaksi', `<button class="btn s" data-act="new" data-entity="transactions">+ Catat</button>`)
    + glass(`<div class="two-col" style="margin:0"><input id="txQ" placeholder="Cari keterangan atau catatan" value="${esc(st.txq || '')}" data-input="txsearch">
      <select id="txT" data-change="txtype"><option value="">Semua jenis</option>
      <option value="in" ${st.txt === 'in' ? 'selected' : ''}>Pemasukan</option><option value="out" ${st.txt === 'out' ? 'selected' : ''}>Pengeluaran</option>
      <option value="transfer" ${st.txt === 'transfer' ? 'selected' : ''}>Transfer</option></select></div>`)
    + `<div id="txList">${txListHtml()}</div>`;
}
function txListHtml() {
  const q = (st.txq || '').toLowerCase();
  const rows = st.D.transactions.filter((t) => (!st.txt || t.type === st.txt)
    && (!q || (t.title || '').toLowerCase().includes(q) || (t.note || '').toLowerCase().includes(q)));
  return glass(rows.slice(0, 200).map(txRow).join('') || '<p class="empty">Tidak ada transaksi yang cocok.</p>');
}
function finDebt() {
  const row = (d) => {
    const left = Math.max(0, num(d.amount) - num(d.paid));
    const pct = num(d.amount) ? num(d.paid) / num(d.amount) * 100 : 0;
    return glass(`<div class="row-between"><div><b>${esc(d.party)}</b><small class="muted">${d.kind === 'utang' ? 'Utang kepada' : 'Piutang dari'} · ${d.due_date ? 'jatuh tempo ' + fdate(d.due_date) : 'tanpa tenggat'}</small></div>
      <span class="pill ${left === 0 ? 'ok' : ''}">${left === 0 ? 'Lunas' : rp(left) + ' sisa'}</span></div>
      ${bar(pct, d.kind === 'utang' ? 'red' : 'green')}
      <div class="row-between"><small class="muted">${rp(d.paid)} dari ${rp(d.amount)}</small>
      <div class="acts">${left > 0 ? `<button class="chip" data-act="paydebt" data-id="${d.id}">${d.kind === 'utang' ? 'Bayar' : 'Terima'}</button>` : ''}
      <button class="chip" data-act="edit" data-entity="debts" data-id="${d.id}">Ubah</button></div></div>`);
  };
  const ut = st.D.debts.filter((d) => d.kind === 'utang');
  const pi = st.D.debts.filter((d) => d.kind === 'piutang');
  return sec('Utang', `<button class="btn s" data-act="new" data-entity="debts">+ Catat</button>`)
    + (ut.map(row).join('') || glass('<p class="empty">Tidak ada utang.</p>'))
    + sec('Piutang') + (pi.map(row).join('') || glass('<p class="empty">Tidak ada piutang.</p>'));
}
function finBudget() {
  const cats = st.D.categories.filter((c) => c.kind !== 'in');
  return sec('Anggaran per kategori', `<button class="btn s" data-act="new" data-entity="categories">+ Kategori</button>`)
    + glass(cats.map((c) => {
      const pct = num(c.budget) ? num(c.spent) / num(c.budget) * 100 : 0;
      return `<div class="li-block" data-act="edit" data-entity="categories" data-id="${c.id}">
        <div class="row-between"><b>${esc(c.name)}</b><small class="muted">${rp(c.spent)}${num(c.budget) ? ' / ' + rp(c.budget) : ''}</small></div>
        ${num(c.budget) ? bar(pct, pct > 100 ? 'red' : '') : '<small class="muted">Tanpa batas anggaran</small>'}</div>`;
    }).join('') || '<p class="empty">Belum ada kategori.</p>');
}
function finGoal() {
  return sec('Goal & tabungan', `<button class="btn s" data-act="new" data-entity="goals">+ Goal</button>`)
    + (st.D.goals.map((g) => {
      const pct = num(g.target) ? num(g.saved) / num(g.target) * 100 : 0;
      return glass(`<div class="row-between"><div><b>${esc(g.name)}</b><small class="muted">${g.due_date ? 'target ' + fdate(g.due_date) : 'tanpa tenggat'}</small></div><span class="pill">${Math.min(100, Math.round(pct))}%</span></div>
        ${bar(pct, 'green')}
        <div class="row-between"><small class="muted">${rp(g.saved)} dari ${rp(g.target)}</small>
        <div class="acts"><button class="chip" data-act="goaladd" data-id="${g.id}">Tabung</button><button class="chip" data-act="edit" data-entity="goals" data-id="${g.id}">Ubah</button></div></div>`);
    }).join('') || glass('<p class="empty">Belum ada goal.</p>'));
}
function finAsset() {
  const total = sumBy(st.D.assets, (a) => num(a.value));
  const cost = sumBy(st.D.assets, (a) => num(a.qty) * num(a.buy_price));
  return sec('Aset & investasi', `<button class="btn s" data-act="new" data-entity="assets">+ Aset</button>`)
    + glass(`<div class="stat"><div><small>Nilai sekarang</small><b>${rp(total)}</b></div><div><small>Untung / rugi</small><b class="${total - cost >= 0 ? 'in' : 'out'}">${rp(total - cost)}</b></div></div>`)
    + glass(st.D.assets.map((a) => {
      const val = num(a.value), gain = val - num(a.qty) * num(a.buy_price);
      return `<div class="li"><span class="tx-ic">${ic(a.type === 'kendaraan' ? 'car' : a.type === 'emas' ? 'target' : 'chart', 16)}</span>
        <div class="g" data-act="edit" data-entity="assets" data-id="${a.id}"><b>${esc(a.name)}</b><small>${esc(a.type)} · ${num(a.qty)} unit</small></div>
        <div class="right"><b>${rp(val)}</b><small class="${gain >= 0 ? 'in' : 'out'}">${gain >= 0 ? '+' : ''}${rp(gain)}</small></div></div>`;
    }).join('') || '<p class="empty">Belum ada aset.</p>');
}
function finRecurring() {
  return sec('Transaksi rutin', `<button class="btn s" data-act="new" data-entity="recurring">+ Rutin</button>`)
    + glass(st.D.recurring.map((r) => `<div class="li"><span class="tx-ic ${r.type}">${ic('repeat', 16)}</span>
      <div class="g" data-act="edit" data-entity="recurring" data-id="${r.id}"><b>${esc(r.title)}</b><small>${r.frequency === 'weekly' ? 'Mingguan' : 'Bulanan'} · berikutnya ${fdate(r.next_date)} · ${esc(walletName(r.wallet_id) || '-')}</small></div>
      <div class="right"><b class="${r.type}">${rp(r.amount)}</b><small class="muted">${r.active ? 'Aktif' : 'Nonaktif'}</small></div></div>`).join('') || '<p class="empty">Belum ada transaksi rutin.</p>');
}
function finWallet() {
  return sec('Wallet', `<button class="btn s" data-act="new" data-entity="wallets">+ Wallet</button>`)
    + glass(st.D.wallets.map((w) => `<div class="li"><span class="tx-ic">${ic('wallet', 16)}</span>
      <div class="g" data-act="edit" data-entity="wallets" data-id="${w.id}"><b>${esc(w.name)}</b><small>${esc(w.type)}</small></div>
      <b class="${num(w.balance) < 0 ? 'out' : ''}">${rp(w.balance)}</b></div>`).join(''))
    + `<p class="muted small">Saldo = saldo awal + pemasukan − pengeluaran ± transfer.</p>`;
}
function finReport() {
  const ym = st.month;
  const mt = monthTx(ym);
  const inc = sumBy(mt.filter((x) => x.type === 'in'), (x) => num(x.amount));
  const out = sumBy(mt.filter((x) => x.type === 'out'), (x) => num(x.amount));
  const byCat = {};
  mt.filter((x) => x.type === 'out').forEach((x) => { const k = catName(x.category_id) || 'Tanpa kategori'; byCat[k] = (byCat[k] || 0) + num(x.amount); });
  const cats = Object.entries(byCat).sort((a, b) => b[1] - a[1]);
  const mx = Math.max(1, ...cats.map((c) => c[1]));
  return `<div class="glass month-nav"><button class="chip" data-act="month" data-d="-1">‹</button><b>${monthName(ym)}</b><button class="chip" data-act="month" data-d="1">›</button></div>`
    + glass(`<div class="stat"><div><small>Pemasukan</small><b class="in">${rp(inc)}</b></div><div><small>Pengeluaran</small><b class="out">${rp(out)}</b></div>
      <div style="grid-column:1/3"><small>Selisih</small><b class="${inc - out >= 0 ? 'in' : 'out'}">${rp(inc - out)}</b></div></div>`)
    + sec('Arus kas per wallet')
    + glass(st.D.wallets.map((w) => {
      const wt = mt.filter((x) => x.wallet_id == w.id || x.to_wallet_id == w.id);
      const masuk = sumBy(wt.filter((x) => x.type === 'in' && x.wallet_id == w.id), (x) => num(x.amount)) + sumBy(wt.filter((x) => x.type === 'transfer' && x.to_wallet_id == w.id), (x) => num(x.amount));
      const keluar = sumBy(wt.filter((x) => x.type === 'out' && x.wallet_id == w.id), (x) => num(x.amount)) + sumBy(wt.filter((x) => x.type === 'transfer' && x.wallet_id == w.id), (x) => num(x.amount));
      return `<div class="li"><div class="g"><b>${esc(w.name)}</b><small>masuk ${rp(masuk)} · keluar ${rp(keluar)}</small></div><b>${rp(w.balance)}</b></div>`;
    }).join('') || '<p class="empty">Belum ada wallet.</p>')
    + sec('Pengeluaran per kategori')
    + glass(cats.map(([k, v]) => `<div class="li-block"><div class="row-between"><b>${esc(k)}</b><small class="muted">${rp(v)}</small></div>${bar(v / mx * 100)}</div>`).join('') || '<p class="empty">Belum ada pengeluaran bulan ini.</p>');
}

function finEmoney() {
  const cards = st.D.wallets.filter((w) => w.type === 'emoney');
  return sec('E-money', `<button class="btn s" data-act="newemoney">+ E-money</button>`)
    + glass('<p class="muted small" style="margin:0">Saldo kartu e-money (Flazz, e-Money, Brizzi, dll) tidak bisa dibaca otomatis dari browser atau HP. Isi sesuai angka di aplikasi bank atau mesin top-up, lalu catat dengan tombol di bawah.</p>')
    + (cards.map((w) => glass(`<div class="row-between"><div><b>${esc(w.name)}</b><small class="muted">Saldo tercatat${w.card_uid ? ' · kartu ' + esc(w.card_uid) : ''}</small></div><b>${rp(w.balance)}</b></div>
      <div class="btn-row"><button class="chip" data-act="emop" data-id="${w.id}" data-op="set">Set saldo</button><button class="chip" data-act="emop" data-id="${w.id}" data-op="top">Isi ulang</button><button class="chip" data-act="emop" data-id="${w.id}" data-op="use">Pakai</button><button class="chip" data-act="nfclink" data-id="${w.id}">Kaitkan NFC</button><button class="chip" data-act="nfccheck" data-id="${w.id}">Cek kartu NFC</button><button class="chip" data-act="edit" data-entity="wallets" data-id="${w.id}">Ubah</button></div>`)).join('')
      || glass('<p class="empty">Belum ada e-money. Tambah dengan tombol di atas.</p>'));
}
function openEmoney(id, op) {
  const w = st.D.wallets.find((x) => x.id == id);
  const bankOpts = st.D.wallets.filter((x) => x.type !== 'emoney').map((x) => `<option value="${x.id}">${esc(x.name)} (${rp(x.balance)})</option>`).join('');
  const title = { set: 'Set saldo kartu', top: 'Isi ulang', use: 'Catat pemakaian' }[op];
  const amountField = op === 'set'
    ? `<label>Saldo sekarang di kartu (Rp)<input name="amount" type="number" inputmode="numeric" data-type="num" value="${num(w.balance)}" required></label>`
    : `<label>Jumlah (Rp)<input name="amount" type="number" inputmode="numeric" data-type="num" required></label>`
      + (op === 'top' ? `<label>Dibayar dari<select name="source"><option value="">— tidak dicatat —</option>${bankOpts}</select></label>` : '');
  sheet(`<h3>${esc(title)}: ${esc(w.name)}</h3>
    <form data-submit="emoney" data-id="${id}" data-op="${op}">${amountField}
      <label>Tanggal<input name="date" type="date" value="${today()}" required></label>
      <label>Keterangan (opsional)<input name="note" maxlength="120"></label>
      <button class="btn" type="submit">Simpan</button></form>`);
}

function finAlokasi() {
  const ym = today().slice(0, 7);
  const income = sumBy(monthTx(ym).filter((x) => x.type === 'in'), (x) => num(x.amount));
  const cats = st.D.categories.filter((c) => c.kind !== 'in');
  const total = sumBy(cats, (c) => num(c.alloc_pct));
  return sec('Alokasi bulanan')
    + glass(`<small class="muted">Pemasukan bulan ini</small><div style="font-size:24px;font-weight:700;margin:2px 0 6px">${rp(income)}</div>
      <p class="muted small" style="margin:0">Total alokasi ${total}% ${total > 100 ? '<span class="out">melebihi 100%</span>' : ''}</p>`)
    + glass(`<form data-submit="alloc">${cats.map((c) => `<div class="li"><div class="g"><b>${esc(c.name)}</b><small>${rp(income * num(c.alloc_pct) / 100)}</small></div>
        <input name="p_${c.id}" type="number" inputmode="numeric" data-type="num" min="0" max="100" value="${num(c.alloc_pct)}" style="width:84px"> %</div>`).join('') || '<p class="empty">Belum ada kategori pengeluaran.</p>'}
        <button class="btn" type="submit">Simpan alokasi</button></form>`);
}

/* ---------- Kalender ---------- */
function pageCal() {
  const [y, m] = st.month.split('-').map(Number);
  const off = (new Date(y, m - 1, 1).getDay() + 6) % 7;
  const dim = new Date(y, m, 0).getDate();
  const ev = {};
  st.D.agenda.forEach((a) => { ev[a.date] = ev[a.date] || []; ev[a.date].push(a); });
  st.D.transactions.forEach((t) => { ev[t.date] = ev[t.date] || []; ev[t.date].push(t); });
  const t = today();
  let cells = ['S', 'S', 'R', 'K', 'J', 'S', 'M'].map((x) => `<div class="h">${x}</div>`).join('') + '<div></div>'.repeat(off);
  for (let d = 1; d <= dim; d++) {
    const k = `${st.month}-${pad(d)}`;
    cells += `<button class="cd ${ev[k] ? 'has' : ''} ${k === t ? 'td' : ''} ${k === st.day ? 'sel' : ''}" data-act="day" data-date="${k}">${d}${ev[k] ? '<i></i>' : ''}</button>`;
  }
  const day = st.day || t;
  const items = ev[day] || [];
  return `<h2 class="page-title">Kalender</h2>
    <div class="glass month-nav"><button class="chip" data-act="month" data-d="-1">‹</button><b>${monthName(st.month)}</b><button class="chip" data-act="month" data-d="1">›</button></div>
    ${glass(`<div class="cal">${cells}</div>`)}
    ${sec(fdate(day) + ' ' + pd(day).getFullYear(), `<button class="btn s" data-act="addday" data-date="${day}">+ Agenda</button>`)}
    ${glass(items.map((x) => (x.kind !== undefined && x.type === undefined ? agendaRow(x) : txRow(x))).join('') || '<p class="empty">Tidak ada kegiatan di tanggal ini.</p>')}`;
}

/* ---------- Kasir / POS ---------- */
function pagePos() {
  const s = st.sub || 'kasir';
  const tabs = [['kasir', 'Kasir'], ['preorder', 'Pre Order'], ['dash', 'Dashboard'], ['stok', 'Stok'], ['menu', 'Menu']];
  const body = { kasir: posKasir, preorder: posPreorder, dash: posDash, stok: posStok, menu: posMenu }[s] || posKasir;
  return `<div class="row-between"><h2 class="page-title">${esc(st.D.settings.pos_name)}</h2><button class="chip" data-act="bizname">Ubah nama</button></div>
    <div class="chips">${tabs.map(([k, l]) => `<button class="chip ${s === k ? 'on' : ''}" data-act="go" data-tab="pos" data-sub="${k}">${l}</button>`).join('')}</div>${body()}`;
}
function posKasir() {
  const prods = st.D.pos_products.filter((p) => p.active);
  if (!prods.length) return glass('<p class="empty">Belum ada menu. Tambah di tab Menu.</p>');
  const grid = prods.map((p) => {
    const q = st.cart[p.id] || 0;
    const mk = maxMake(p.id);
    const full = hasRecipe(p.id) && mk <= q;
    const status = !hasRecipe(p.id) ? 'Tanpa resep' : mk > 0 ? `Sisa ${mk} porsi` : 'Stok habis';
    return `<div class="glass tile ${q ? 'picked' : ''}"><div class="tile-name">${esc(p.name)}</div><div class="tile-price">${rp(p.price)}</div><small class="muted">${status}</small>
      <div class="qty"><button data-act="cq" data-id="${p.id}" data-d="-1" ${q ? '' : 'disabled'} aria-label="Kurangi">−</button><span>${q}</span><button data-act="cq" data-id="${p.id}" data-d="1" ${full ? 'disabled' : ''} aria-label="Tambah">+</button></div></div>`;
  }).join('');
  const n = Object.values(st.cart).reduce((a, b) => a + b, 0);
  return `<div class="tiles">${grid}</div>
    <div class="glass cartbar">${n ? `<div><small>${n} item</small><b>${rp(cartTotal())}</b></div><button class="btn s" data-act="paynow">Bayar</button>` : '<small class="muted">Ketuk + untuk memilih menu</small>'}</div>`;
}
function posDash() {
  const t = today();
  const ss = st.D.pos_sales;
  const day = (s) => ymd(new Date(s.ts * 1000));
  const todays = ss.filter((s) => day(s) === t);
  const omzet = sumBy(todays, (s) => num(s.total));
  const hpp = sumBy(todays, (s) => num(s.hpp));
  const days = [...Array(7)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - (6 - i)); const k = ymd(d); return { l: d.getDate(), v: sumBy(ss.filter((s) => day(s) === k), (s) => num(s.total)) }; });
  const mx = Math.max(1, ...days.map((d) => d.v));
  const tally = {};
  st.D.pos_sale_items.forEach((i) => { tally[i.name] = (tally[i.name] || 0) + num(i.qty); });
  const top = Object.entries(tally).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const low = Number(st.D.settings.low_stock) || 500;
  const lows = st.D.pos_ingredients.filter((i) => num(i.stock_g) < low);
  return glass(`<h3>Hari ini</h3><div class="stat"><div><small>Omzet</small><b>${rp(omzet)}</b></div><div><small>Laba kotor</small><b class="in">${rp(omzet - hpp)}</b></div><div><small>Transaksi</small><b>${todays.length}</b></div><div><small>HPP</small><b>${rp(hpp)}</b></div></div>`)
    + glass(`<h3>Omzet 7 hari</h3><div class="bars">${days.map((d) => `<div><i style="height:${(d.v / mx * 100).toFixed(1)}%"></i><small>${d.l}</small></div>`).join('')}</div>`)
    + glass(`<h3>Menu terlaris</h3>${top.map(([n, q]) => `<div class="li"><div class="g"><b>${esc(n)}</b></div><b>${q} porsi</b></div>`).join('') || '<p class="empty">Belum ada penjualan.</p>'}`)
    + glass(`<h3>Stok menipis</h3>${lows.map((i) => `<div class="li"><div class="g"><b>${esc(i.name)}</b></div><span class="pill warn">${gr(i.stock_g)}</span></div>`).join('') || '<p class="empty">Semua bahan aman.</p>'}`);
}
function posStok() {
  const low = Number(st.D.settings.low_stock) || 500;
  return sec('Bahan & stok', `<button class="btn s" data-act="purchase">+ Beli bahan</button>`)
    + glass(st.D.pos_ingredients.map((i) => `<div class="li"><div class="g"><b>${esc(i.name)}</b><small>HPP ${rp(avgCost(i))}/gr · total beli ${gr(i.total_g)}</small></div>
      <div class="right"><b>${gr(i.stock_g)}</b><br><span class="pill ${num(i.stock_g) < low ? 'warn' : ''}">${num(i.stock_g) < low ? 'menipis' : 'aman'}</span></div></div>`).join('') || '<p class="empty">Belum ada bahan.</p>')
    + sec('Pembelian terakhir')
    + glass(st.D.pos_purchases.slice(0, 10).map((p) => `<div class="li"><div class="g"><b>${esc(p.ingredient_name || '-')}</b><small>${fdate(p.date)} · ${gr(p.grams)}</small></div><b>${rp(p.cost)}</b></div>`).join('') || '<p class="empty">Belum ada pembelian.</p>');
}
function posMenu() {
  return sec('Menu & resep', `<button class="btn s" data-act="newprod">+ Menu</button>`)
    + st.D.pos_products.map((p) => {
      const h = hppOf(p.id), m = num(p.price) - h;
      const recs = st.D.pos_recipes.filter((r) => r.product_id == p.id);
      return glass(`<div class="row-between"><b>${esc(p.name)}</b><b>${rp(p.price)}</b></div>
        <small class="muted">HPP ${rp(h)} · laba ${rp(m)} (${num(p.price) ? Math.round(m / num(p.price) * 100) : 0}%)</small>
        <div style="margin-top:8px">${recs.map((r) => `<div class="li"><div class="g"><small style="color:var(--ink)">${esc(ING(r.ingredient_id)?.name || '?')}</small></div><small>${num(r.grams)} gr · ${rp(avgCost(ING(r.ingredient_id)) * num(r.grams))}</small></div>`).join('') || '<p class="muted small">Belum ada resep</p>'}</div>
        <div class="btn-row"><button class="chip" data-act="editprod" data-id="${p.id}">Ubah</button><button class="chip" data-act="del" data-entity="pos_products" data-id="${p.id}">Hapus</button></div>`);
    }).join('') || glass('<p class="empty">Belum ada menu.</p>');
}

function cq(id, d) {
  const q = Math.max(0, (st.cart[id] || 0) + d);
  if (q) st.cart[id] = q; else delete st.cart[id];
  render();
}
function paynow() {
  if (!Object.keys(st.cart).length) return toast('Keranjang masih kosong');
  const need = {};
  Object.keys(st.cart).forEach((pid) => st.D.pos_recipes.filter((r) => r.product_id == pid).forEach((r) => { need[r.ingredient_id] = (need[r.ingredient_id] || 0) + num(r.grams) * st.cart[pid]; }));
  for (const iid in need) { const i = ING(iid); if (i && num(i.stock_g) < need[iid]) return toast(`Stok ${i.name} tidak cukup`); }
  const total = cartTotal();
  sheet(`<h3>Pembayaran</h3><div class="total-box"><small>Total</small><b>${rp(total)}</b></div>
    <form data-submit="possale">
      <label>Metode<select name="pay"><option>Tunai</option><option>QRIS</option><option>Transfer</option></select></label>
      <label>Uang diterima (Rp)<input name="cash" type="number" inputmode="numeric" data-type="num" data-input="cash" data-total="${total}" value="${total}"></label>
      <p class="muted">Kembalian: <b id="kembali">${rp(0)}</b></p>
      <label>Catat ke wallet<select name="wallet_id"><option value="">— tidak dicatat —</option>${walletOpts(st.D.wallets[0]?.id)}</select></label>
      <button class="btn" type="submit">Selesaikan &amp; cetak struk</button>
    </form>`);
}
function strukText(s) {
  const W = 32;
  const C = (t) => ' '.repeat(Math.max(0, Math.floor((W - t.length) / 2))) + t;
  const L = (a, b) => { a = String(a); b = String(b); return a + ' '.repeat(Math.max(1, W - a.length - b.length)) + b; };
  const d = new Date(s.ts * 1000);
  const line = '-'.repeat(W);
  const out = [C(st.D.settings.pos_name.toUpperCase()), C('STRUK PEMBELIAN'), line,
    'No  : ' + String(s.no).padStart(4, '0'),
    `Tgl : ${d.getDate()} ${BL[d.getMonth()].slice(0, 3)} ${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`, line];
  s.items.forEach((i) => { out.push(i.name); out.push(L(`  ${i.qty} x ${rp(i.price)}`, rp(i.price * i.qty))); });
  out.push(line, L('TOTAL', rp(s.total)), L(`Bayar (${s.pay})`, rp(s.bayar)));
  if (s.pay === 'Tunai') out.push(L('Kembali', rp(Math.max(0, s.bayar - s.total))));
  out.push(line, C('Terima kasih!'));
  return out.join('\n');
}
function receiptHtml() {
  return `<h3>Struk</h3><div class="struk-wrap">${st.D.settings.logo_url ? `<img class="struk-logo" src="${esc(st.D.settings.logo_url)}" alt="">` : ''}<pre class="struk" id="struk">${esc(strukText(st.sale))}</pre></div>
    <div class="btn-row"><button class="btn s" data-act="wa">WhatsApp</button><button class="btn s ghost" data-act="share">Bagikan</button><button class="btn s ghost" data-act="print">Cetak</button><button class="btn s ghost" data-act="close">Tutup</button></div>`;
}
function waSend() {
  const n = window.prompt('Nomor WA pelanggan (boleh kosong):', '') || '';
  let p = n.replace(/\D/g, '');
  if (p.startsWith('0')) p = '62' + p.slice(1);
  window.open(`https://wa.me/${p}?text=${encodeURIComponent(strukText(st.sale))}`, '_blank', 'noopener');
}
function shareStruk() {
  const t = strukText(st.sale);
  if (navigator.share) { navigator.share({ text: t }).catch(() => {}); return; }
  navigator.clipboard.writeText(t).then(() => toast('Struk disalin'), () => toast('Gagal menyalin'));
}

function openProd(id) {
  const p = id ? PRD(id) : null;
  st.rd = {
    id: id || 0,
    name: p ? p.name : '',
    price: p ? p.price : '',
    recipe: id ? st.D.pos_recipes.filter((r) => r.product_id == id).map((r) => ({ ingredient_id: Number(r.ingredient_id), grams: num(r.grams) })) : [],
  };
  renderProdSheet();
}
function syncRd(f) {
  st.rd.name = f.querySelector('[name=pname]').value;
  st.rd.price = f.querySelector('[name=pprice]').value;
}
function renderProdSheet() {
  const rd = st.rd;
  const ingOpts = st.D.pos_ingredients.map((i) => `<option value="${i.id}">${esc(i.name)}</option>`).join('');
  sheet(`<h3>${rd.id ? 'Ubah menu' : 'Menu baru'}</h3>
    <form data-submit="product" data-id="${rd.id}">
      <label>Nama menu<input name="pname" value="${esc(rd.name)}" required maxlength="120"></label>
      <label>Harga jual (Rp)<input name="pprice" type="number" inputmode="numeric" value="${esc(rd.price)}" required></label>
      <h3 style="margin-top:16px">Resep per gelas</h3>
      ${rd.recipe.map((r, i) => `<div class="li"><div class="g"><b>${esc(ING(r.ingredient_id)?.name || '?')}</b><small>${r.grams} gr · HPP ${rp(avgCost(ING(r.ingredient_id)) * r.grams)}</small></div><button type="button" class="chip" data-act="rowrm" data-i="${i}">Hapus</button></div>`).join('') || '<p class="muted">Belum ada bahan</p>'}
      <div class="two-col" style="margin-top:10px"><label>Bahan<select name="ing">${ingOpts}</select></label><label>Gram<input name="grams" type="number" inputmode="decimal" step="any"></label></div>
      <button type="button" class="btn ghost" data-act="rowadd">+ Tambah bahan</button>
      <button class="btn" type="submit">Simpan menu</button>
    </form>`);
}
function recipeAdd() {
  const f = $('#sb form'); syncRd(f);
  const ing = Number(f.querySelector('[name=ing]').value);
  const g = Number(f.querySelector('[name=grams]').value);
  if (!ing || !g) throw new Error('Pilih bahan dan isi gramnya');
  st.rd.recipe.push({ ingredient_id: ing, grams: g });
  renderProdSheet();
}
function recipeRm(i) {
  const f = $('#sb form'); if (f) syncRd(f);
  st.rd.recipe.splice(i, 1);
  renderProdSheet();
}
function openPurchase() {
  sheet(`<h3>Beli bahan</h3>
    <form data-submit="post" data-endpoint="pos.purchase">
      <label>Bahan<select name="ingredient_id"><option value="">+ Bahan baru</option>${st.D.pos_ingredients.map((i) => `<option value="${i.id}">${esc(i.name)}</option>`).join('')}</select></label>
      <label>Nama bahan baru (jika memilih "Bahan baru")<input name="new_name" maxlength="120"></label>
      <div class="two-col"><label>Jumlah<input name="qty" type="number" inputmode="decimal" step="any" data-type="num" required></label>
      <label>Satuan<select name="unit"><option value="gr">gr</option><option value="kg">kg</option><option value="ml">ml</option><option value="liter">liter</option></select></label></div>
      <label>Total harga beli (Rp)<input name="cost" type="number" inputmode="numeric" data-type="num" required></label>
      <label>Tanggal<input name="date" type="date" value="${today()}" required></label>
      <label>Bayar dari wallet<select name="wallet_id"><option value="">— tidak dicatat —</option>${walletOpts()}</select></label>
      <p class="muted small">Liter dan ml dihitung 1 ml = 1 gr.</p>
      <button class="btn" type="submit">Simpan pembelian</button>
    </form>`);
}
function openPay(kind, id) {
  if (kind === 'debt') {
    const d = st.D.debts.find((x) => x.id == id);
    const left = Math.max(0, num(d.amount) - num(d.paid));
    sheet(`<h3>${d.kind === 'utang' ? 'Bayar utang' : 'Terima piutang'}: ${esc(d.party)}</h3>
      <form data-submit="post" data-endpoint="debt.pay" data-extra='{"debt_id":${id}}'>
        <label>Jumlah (Rp)<input name="amount" type="number" inputmode="numeric" data-type="num" value="${left}" required></label>
        <label>Tanggal<input name="date" type="date" value="${today()}" required></label>
        <label>${d.kind === 'utang' ? 'Dari wallet' : 'Masuk ke wallet'}<select name="wallet_id"><option value="">— tidak dicatat —</option>${walletOpts()}</select></label>
        <button class="btn" type="submit">Simpan pembayaran</button>
      </form>`);
  } else {
    const g = st.D.goals.find((x) => x.id == id);
    sheet(`<h3>Tabung untuk ${esc(g.name)}</h3>
      <form data-submit="post" data-endpoint="goal.add" data-extra='{"goal_id":${id}}'>
        <label>Jumlah (Rp)<input name="amount" type="number" inputmode="numeric" data-type="num" required></label>
        <label>Tanggal<input name="date" type="date" value="${today()}" required></label>
        <label>Dari wallet<select name="wallet_id"><option value="">— tidak dicatat —</option>${walletOpts()}</select></label>
        <button class="btn" type="submit">Simpan tabungan</button>
      </form>`);
  }
}

/* ---------- Lainnya ---------- */
const menuRow = (i, t, s, tab, sub) => `<button class="mi" data-act="go" data-tab="${tab}" data-sub="${sub}"><span class="ic-tile">${ic(i, 20)}</span><div><b>${t}</b><small>${s}</small></div></button>`;
function pageMore() {
  const s = st.sub;
  if (s === 'maint') {
    const l = st.D.agenda.filter((a) => a.category === 'Maintenance').sort((a, b) => a.date.localeCompare(b.date));
    return `<button class="chip" data-act="go" data-tab="more" data-sub="">‹ Kembali</button><h2 class="page-title">Maintenance</h2>
      <button class="btn" data-act="addmaint">+ Jadwal servis</button>
      ${glass(l.map((a) => agendaRow(a) + `<small class="muted" style="margin:-8px 0 8px 38px;display:block">${fdate(a.date)}</small>`).join('') || '<p class="empty">Belum ada jadwal servis.</p>')}`;
  }
  if (s === 'journal') {
    return `<button class="chip" data-act="go" data-tab="more" data-sub="">‹ Kembali</button><h2 class="page-title">Jurnal keluarga</h2>
      <button class="btn" data-act="new" data-entity="journal">+ Tulis catatan</button>
      ${st.D.journal.map((j) => glass(`<div data-act="edit" data-entity="journal" data-id="${j.id}"><small class="muted">${fdate(j.date)}</small><p style="margin:4px 0 0;white-space:pre-wrap">${esc(j.text)}</p></div>`)).join('') || glass('<p class="empty">Belum ada catatan.</p>')}`;
  }
  if (s === 'import') return importView();
  if (s === 'settings') return settingsView();
  if (s === 'perms') return permsView();
  return `<h2 class="page-title">Lainnya</h2>
    ${glass(`<div class="li"><div class="logo" style="width:44px;height:44px;border-radius:50%">${esc((st.D.settings.family_name || 'K')[0].toUpperCase())}</div><div class="g"><b>${esc(st.D.settings.family_name)}</b><small>${esc(st.user?.username || '')}</small></div></div>`)}
    ${glass(menuRow('tool', 'Maintenance', 'Servis kendaraan & perawatan rumah', 'more', 'maint')
      + menuRow('book', 'Jurnal keluarga', 'Catatan bersama', 'more', 'journal')
      + menuRow('chart', 'Laporan keuangan', 'Ringkasan per bulan', 'fin', 'laporan')
      + menuRow('repeat', 'Transaksi rutin', 'Tagihan & langganan otomatis', 'fin', 'rutin')
      + menuRow('target', 'Goal & tabungan', 'Target dan progres', 'fin', 'goal')
      + menuRow('car', 'Aset & investasi', 'Saham, emas, properti, kendaraan', 'fin', 'aset')
      + menuRow('wallet', 'E-money', 'Saldo kartu Flazz, e-Money, dll', 'fin', 'emoney')
      + menuRow('cloud', 'Cuaca', 'Prakiraan 5 hari di beranda', 'home', '')
      + menuRow('shield', 'Izin aplikasi', 'Notifikasi, lokasi, kamera, kalender, NFC', 'more', 'perms')
      + menuRow('import', 'Import MoneyNest', 'Pindahkan data dari aplikasi lama', 'more', 'import')
      + menuRow('gear', 'Pengaturan', 'Profil, tema, lokasi cuaca, password', 'more', 'settings'))}
    <button class="btn ghost" data-act="logout">${ic('logout', 16)} Keluar</button>`;
}
function settingsView() {
  const s = st.D.settings;
  return `<button class="chip" data-act="go" data-tab="more" data-sub="">‹ Kembali</button><h2 class="page-title">Pengaturan</h2>
    ${glass(`<form data-submit="settings">
      <label>Nama keluarga<input name="family_name" value="${esc(s.family_name)}" required maxlength="80"></label>
      <label>Tema<select name="theme" data-change="theme">${[['auto', 'Ikuti HP'], ['light', 'Terang'], ['dark', 'Gelap']].map(([v, l]) => `<option value="${v}" ${s.theme === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
      <label>Nama usaha POS<input name="pos_name" value="${esc(s.pos_name)}" maxlength="80"></label>
      <label>Batas stok menipis (gr)<input name="low_stock" type="number" inputmode="numeric" data-type="num" value="${esc(s.low_stock)}"></label>
      <button class="btn" type="submit">Simpan</button></form>`)}
    ${sec('Lokasi cuaca')}
    ${glass(`<div class="geo-row"><input id="geoQ" placeholder="Cari kota, mis. Pontianak" maxlength="80"><button class="chip" data-act="geosearch">Cari</button></div>
      <p class="muted small">Sekarang: ${esc(s.weather_name)}</p><div id="geoRes"></div>`)}
    <button class="btn ghost" data-act="export">Unduh semua data (JSON)</button>
    ${st.user?.role === 'master' ? masterView() + userAdminView() : ''}
    ${sec('Ganti password')}
    ${glass(`<form data-submit="password">
      <label>Password sekarang<input name="current" type="password" autocomplete="current-password" required></label>
      <label>Password baru (min. 8 karakter)<input name="next" type="password" autocomplete="new-password" minlength="8" required></label>
      <button class="btn" type="submit">Ganti password</button></form>`)}`;
}
function importView() {
  return `<button class="chip" data-act="go" data-tab="more" data-sub="">‹ Kembali</button><h2 class="page-title">Import MoneyNest</h2>
    ${glass(`<p class="muted small" style="margin-top:0">Unggah ekspor dari MoneyNest berupa <b>.sqlite / .db</b> (database langsung), <b>.json</b>, atau <b>.csv</b>. Lakukan <b>pratinjau</b> dulu untuk melihat tabel dan kolom yang terdeteksi, lalu impor.</p>
      <input id="importFile" type="file" accept=".sqlite,.sqlite3,.db,.json,.csv">
      <div class="btn-row"><button class="btn s ghost" data-act="importrun" data-dry="1">Pratinjau</button><button class="btn s" data-act="importrun" data-dry="0">Impor sekarang</button></div>`)}
    ${st.importRes ? importReport(st.importRes) : ''}`;
}
function importReport(res) {
  const rows = Object.entries(res.tables).map(([n, t]) => `<div class="li"><div class="g"><b>${esc(n)}</b><small>Jenis: ${esc(t.role)} · ${t.rows} baris</small>
    ${t.kolom_tidak_terpakai.length ? `<small class="warnText">Kolom belum dipakai: ${t.kolom_tidak_terpakai.map((c) => esc(c)).join(', ')}</small>` : ''}</div></div>`).join('');
  const cnt = Object.entries(res.counts).filter(([, v]) => v).map(([k, v]) => `${k}: ${v}`).join(' · ');
  return glass(`<h3>${res.dry ? 'Pratinjau (belum disimpan)' : 'Hasil impor'}</h3>${rows || '<p class="empty">Tidak ada tabel yang terbaca.</p>'}
    <p class="muted small">${esc(cnt) || 'Tidak ada data yang diproses.'}</p>${res.warnings.map((w) => `<p class="warnText">${esc(w)}</p>`).join('')}`);
}
async function runImport(dry) {
  const file = $('#importFile')?.files?.[0];
  if (!file) throw new Error('Pilih file dulu');
  if (!dry && !window.confirm('Impor sekarang? Data akan ditambahkan ke SERumah.')) return;
  const fd = new FormData();
  fd.append('file', file);
  fd.append('dry', dry ? '1' : '0');
  st.importRes = await api('import', { form: fd });
  if (!dry) { await refresh(); toast('Impor selesai'); } else render();
}
async function geoSearch() {
  const q = $('#geoQ').value.trim();
  if (q.length < 2) throw new Error('Ketik minimal 2 huruf');
  const list = await api('geocode', { q });
  $('#geoRes').innerHTML = list.map((g) => `<div class="li"><div class="g"><b>${esc(g.name)}</b><small>${esc([g.region, g.country].filter(Boolean).join(', '))}</small></div>
    <button class="chip" data-act="geopick" data-name="${esc(g.name)}" data-lat="${Number(g.lat)}" data-lon="${Number(g.lon)}">Pilih</button></div>`).join('') || '<p class="empty">Lokasi tidak ditemukan.</p>';
}
async function geoPick(name, lat, lon) {
  await api('settings.save', { json: { values: { weather_name: name, weather_lat: lat, weather_lon: lon } } });
  toast('Lokasi cuaca diperbarui');
  await refresh();
}

/* ---------- formulir generik ---------- */
function fieldHtml(f, v) {
  if (f.bool) return `<label class="check"><input type="checkbox" name="${f.k}" ${Number(v) ? 'checked' : ''}> ${esc(f.l)}</label>`;
  if (f.sel) {
    let opts = f.sel;
    if (f.sel === 'wallets') opts = st.D.wallets.map((w) => [w.id, w.name]);
    if (f.sel === 'categories') opts = st.D.categories.map((c) => [c.id, c.name]);
    return `<label>${esc(f.l)}<select name="${f.k}"><option value="">— pilih —</option>${opts.map(([a, b]) => `<option value="${esc(a)}" ${String(a) === String(v ?? '') ? 'selected' : ''}>${esc(b)}</option>`).join('')}</select></label>`;
  }
  if (f.t) return `<label>${esc(f.l)}<input type="time" name="${f.k}" value="${esc(v)}"></label>`;
  if (f.ta) return `<label>${esc(f.l)}<textarea name="${f.k}" rows="3">${esc(v)}</textarea></label>`;
  return `<label>${esc(f.l)}<input type="${f.d ? 'date' : f.n ? 'number' : 'text'}" name="${f.k}" value="${esc(v)}" ${f.n ? 'inputmode="decimal" step="any" data-type="num"' : ''} ${f.req ? 'required' : ''}></label>`;
}
function openForm(entity, id = 0, prefill = {}) {
  const def = FORMS[entity];
  const table = TABLE_OF[entity];
  const rec = id ? (st.D[table] || []).find((x) => x.id == id) || {} : {};
  const fieldVal = (f) => {
    if (f.k in rec) return rec[f.k];
    if (f.k in prefill) return prefill[f.k];
    if (f.def === 'today') return today();
    return f.def ?? '';
  };
  const cal = entity === 'agenda' && id ? `<button class="btn ghost" type="button" data-act="calAdd" data-id="${id}">Tambah ke kalender HP</button>` : '';
  const del = id ? `<button class="btn ghost danger" type="button" data-act="del" data-entity="${entity}" data-id="${id}">Hapus</button>` : '';
  sheet(`<h3>${id ? 'Ubah' : 'Tambah'} ${esc(def.t)}</h3>
    <form data-submit="entity" data-entity="${entity}" data-id="${id}">${def.f.map((f) => fieldHtml(f, fieldVal(f))).join('')}
      ${cal}<button class="btn" type="submit">Simpan</button>${del}</form>`);
}
function openAdd() {
  const items = [['transactions', 'Transaksi', 'wallet'], ['debts', 'Utang / piutang', 'debt'], ['agenda', 'Agenda', 'cal'], ['goals', 'Goal', 'target'], ['assets', 'Aset', 'chart'], ['recurring', 'Transaksi rutin', 'repeat'], ['wallets', 'Wallet', 'wallet'], ['journal', 'Catatan jurnal', 'book']];
  sheet(`<h3>Tambah</h3>${items.map(([e, l, i]) => `<button class="mi" data-act="new" data-entity="${e}"><span class="ic-tile">${ic(i, 20)}</span><div><b>${l}</b></div></button>`).join('')}`);
}
function collect(form) {
  const out = {};
  for (const el of form.elements) {
    if (!el.name) continue;
    if (el.type === 'checkbox') out[el.name] = el.checked ? 1 : 0;
    else if (el.dataset.type === 'num') out[el.name] = el.value === '' ? 0 : Number(el.value);
    else out[el.name] = el.value === '' ? null : el.value;
  }
  return out;
}

/* ---------- aksi & submit ---------- */
const ACT = {
  go: (el) => go(el.dataset.tab, el.dataset.sub || ''),
  add: () => openAdd(),
  new: (el) => openForm(el.dataset.entity),
  addday: (el) => openForm('agenda', 0, { date: el.dataset.date }),
  addmaint: () => openForm('agenda', 0, { category: 'Maintenance', kind: 'tugas' }),
  edit: (el) => openForm(el.dataset.entity, Number(el.dataset.id)),
  del: async (el) => {
    if (!window.confirm('Hapus data ini?')) return;
    await api('crud.delete', { json: { entity: el.dataset.entity, id: Number(el.dataset.id) } });
    closeSheet(); toast('Dihapus'); await refresh();
  },
  toggle: async (el) => {
    const a = st.D.agenda.find((x) => x.id == el.dataset.id);
    await api('crud.save', { json: { entity: 'agenda', data: { id: a.id, done: a.done ? 0 : 1 } } });
    await refresh();
  },
  paydebt: (el) => openPay('debt', Number(el.dataset.id)),
  goaladd: (el) => openPay('goal', Number(el.dataset.id)),
  month: (el) => { st.month = shiftMonth(st.month, Number(el.dataset.d)); render(); },
  day: (el) => { st.day = el.dataset.date; render(); },
  cq: (el) => cq(Number(el.dataset.id), Number(el.dataset.d)),
  paynow: () => paynow(),
  purchase: () => openPurchase(),
  newprod: () => openProd(0),
  editprod: (el) => openProd(Number(el.dataset.id)),
  rowadd: () => recipeAdd(),
  rowrm: (el) => recipeRm(Number(el.dataset.i)),
  wa: () => waSend(),
  share: () => shareStruk(),
  print: () => window.print(),
  close: () => closeSheet(),
  bizname: async () => {
    const n = window.prompt('Nama usaha', st.D.settings.pos_name);
    if (n && n.trim()) { await api('settings.save', { json: { values: { pos_name: n.trim() } } }); await refresh(); }
  },
  geosearch: () => geoSearch(),
  geopick: (el) => geoPick(el.dataset.name, el.dataset.lat, el.dataset.lon),
  importrun: (el) => runImport(el.dataset.dry === '1'),
  locate: () => locateMe(false),
  prepay: (el) => openPayPreorder(Number(el.dataset.id)),
  nfccheck: (el) => nfcLink(Number(el.dataset.id), () => openEmoney(Number(el.dataset.id), 'set')),
  export: () => exportData(),
  permreq: async (el) => {
    const p = PERMS.find((x) => x.key === el.dataset.key);
    try {
      if (!p?.req) throw new Error('Fitur ini belum tersedia di APK');
      await p.req(window.Capacitor?.Plugins || {});
    } catch (err) {
      toast(err?.message || 'Permintaan izin gagal. Periksa Pengaturan Android.');
    }
    await refreshPermStatus();
  },
  nfclink: (el) => nfcLink(Number(el.dataset.id)),
  calAdd: (el) => calAdd(Number(el.dataset.id)),
  emop: (el) => openEmoney(Number(el.dataset.id), el.dataset.op),
  newemoney: () => openForm('wallets', 0, { type: 'emoney' }),
  saveAppear: async () => {
    await api('settings.save', { json: { values: { app_name: $('#mAppName').value.trim(), accent: $('#mAcc').value, accent2: $('#mAcc2').value } } });
    toast('Tampilan disimpan'); await refresh();
  },
  upload: async (el) => {
    const file = $(el.dataset.purpose === 'logo' ? '#upLogo' : '#upIcon').files[0];
    if (!file) throw new Error('Pilih file dulu');
    if (!/\.(png|jpe?g|webp|svg)$/i.test(file.name)) throw new Error('Format harus PNG, JPG, WEBP, atau SVG');
    if (file.size > 10 * 1024 * 1024) throw new Error('Ukuran maksimal 10 MB');
    toast('Mengunggah...');
    const fd = new FormData();
    fd.append('file', file);
    fd.append('purpose', el.dataset.purpose);
    await api('upload', { form: fd });
    toast('Berhasil diunggah'); await refresh();
  },
  newpre: () => openPreorder(0),
  editpre: (el) => openPreorder(Number(el.dataset.id)),
  porstatus: (el) => openStatus(Number(el.dataset.id)),
  porset: async (el) => {
    await api('preorder.status', { json: { id: Number(el.dataset.id), status: el.dataset.s } });
    closeSheet(); toast('Status diubah'); await refresh();
  },
  logout: async () => {
    await api('auth.logout', { json: {} });
    const me = await api('auth.me');
    st.csrf = me.csrf; st.user = null; st.D = null;
    renderLogin(); toast('Sudah keluar');
  },
};

const SUBMIT = {
  login: async (f) => {
    const geo = getPosition().catch((e) => e); // dipanggil dalam gestur klik supaya prompt izin lokasi muncul
    const r = await api('auth.login', { json: collect(f) });
    st.csrf = r.csrf; st.user = r.user;
    requestPermissions();
    await refresh();
    const g = await geo;
    if (g && g.coords) await applyLocation(g);
    else if (g instanceof Error) toast(geo.code === 1 ? 'Izin lokasi ditolak. Aktifkan lewat pengaturan browser/HP agar cuaca otomatis.' : 'Lokasi belum tersedia: ' + geo.message);
  },
  entity: async (f) => {
    const data = collect(f);
    const id = Number(f.dataset.id) || 0;
    if (id) data.id = id;
    await api('crud.save', { json: { entity: f.dataset.entity, data } });
    closeSheet(); toast('Tersimpan'); await refresh();
  },
  post: async (f) => {
    const extra = JSON.parse(f.dataset.extra || '{}');
    await api(f.dataset.endpoint, { json: Object.assign(collect(f), extra) });
    closeSheet(); toast('Tersimpan'); await refresh();
  },
  possale: async (f) => {
    const d = collect(f);
    const items = Object.keys(st.cart).map((id) => ({ product_id: Number(id), qty: st.cart[id] }));
    const res = await api('pos.sale', { json: { items, pay: d.pay, cash: d.cash, wallet_id: d.wallet_id } });
    st.sale = { ...res, bayar: d.pay === 'Tunai' ? Number(d.cash) || 0 : res.total };
    st.cart = {};
    closeSheet();
    await refresh();
    sheet(receiptHtml());
  },
  product: async (f) => {
    const name = f.querySelector('[name=pname]').value.trim();
    const price = Number(f.querySelector('[name=pprice]').value) || 0;
    if (!st.rd.recipe.length) throw new Error('Tambah minimal satu bahan');
    const saved = await api('crud.save', { json: { entity: 'pos_products', data: { id: Number(f.dataset.id) || 0, name, price, active: 1 } } });
    await api('pos.recipe', { json: { product_id: saved.id, items: st.rd.recipe } });
    closeSheet(); toast('Menu tersimpan'); await refresh();
  },
  settings: async (f) => {
    const d = collect(f);
    await api('settings.save', { json: { values: { family_name: d.family_name, pos_name: d.pos_name, low_stock: d.low_stock } } });
    toast('Pengaturan disimpan'); await refresh();
  },
  preorder: async (f) => {
    const d = collect(f);
    const items = st.D.pos_products.filter((p) => p.active).map((p) => ({ product_id: p.id, qty: Number(d['q_' + p.id]) || 0 }));
    await api('preorder.save', { json: { id: Number(f.dataset.id) || 0, customer_id: d.customer_id, needed_date: d.needed_date, dp: d.dp, note: d.note, items } });
    closeSheet(); toast('Pre order tersimpan'); await refresh();
  },
  prepay: async (f) => {
    const d = collect(f);
    await api('preorder.pay', { json: { id: Number(f.dataset.id), amount: d.amount, wallet_id: d.wallet_id } });
    closeSheet(); toast('Pembayaran dicatat'); await refresh();
  },
  usersave: async (f) => {
    await api('user.save', { json: collect(f) });
    f.reset(); toast('Akun tersimpan'); await refresh();
  },
  alloc: async (f) => {
    const d = collect(f);
    const cats = st.D.categories.filter((c) => c.kind !== 'in');
    const clamp = (v) => Math.max(0, Math.min(100, Number(v) || 0));
    if (cats.reduce((a, c) => a + clamp(d['p_' + c.id]), 0) > 100) throw new Error('Total alokasi melebihi 100%');
    for (const c of cats) await api('crud.save', { json: { entity: 'categories', data: { id: c.id, alloc_pct: clamp(d['p_' + c.id]) } } });
    toast('Alokasi disimpan'); await refresh();
  },
  emoney: async (f) => {
    const d = collect(f);
    const id = Number(f.dataset.id), op = f.dataset.op;
    const w = st.D.wallets.find((x) => x.id == id);
    const amount = Math.abs(Math.round(Number(d.amount) || 0));
    const base = { date: d.date, note: d.note || '' };
    if (op === 'set') {
      const diff = amount - num(w.balance);
      if (diff === 0) return toast('Saldo sudah sesuai');
      await api('crud.save', { json: { entity: 'transactions', data: { ...base, title: 'Penyesuaian saldo ' + w.name, amount: Math.abs(diff), type: diff > 0 ? 'in' : 'out', wallet_id: id } } });
    } else {
      if (!amount) throw new Error('Isi jumlah dulu');
      if (op === 'top' && d.source) {
        await api('crud.save', { json: { entity: 'transactions', data: { ...base, title: 'Isi ulang ' + w.name, amount, type: 'transfer', wallet_id: Number(d.source), to_wallet_id: id } } });
      } else if (op === 'top') {
        await api('crud.save', { json: { entity: 'transactions', data: { ...base, title: 'Isi ulang ' + w.name, amount, type: 'in', wallet_id: id } } });
      } else {
        await api('crud.save', { json: { entity: 'transactions', data: { ...base, title: 'Pemakaian ' + w.name, amount, type: 'out', wallet_id: id } } });
      }
    }
    closeSheet(); toast('Tersimpan'); await refresh();
  },
  password: async (f) => {
    await api('auth.password', { json: collect(f) });
    f.reset(); toast('Password diganti');
  },
};

/* ---------- event delegation (tanpa handler inline: aman untuk CSP) ---------- */
document.addEventListener('click', async (e) => {
  if (e.target.id === 'sheet') return closeSheet();
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const fn = ACT[el.dataset.act];
  if (!fn) return;
  e.preventDefault();
  try { await fn(el); } catch (err) { toast(err.message); }
});
document.addEventListener('submit', async (e) => {
  const f = e.target;
  const key = f.dataset && f.dataset.submit;
  if (!key) return;
  e.preventDefault();
  try { await SUBMIT[key](f); } catch (err) {
    if (key === 'login') { const el = $('#loginErr'); if (el) el.textContent = err.message; }
    else toast(err.message);
  }
});
document.addEventListener('change', (e) => {
  const el = e.target;
  if (el.dataset && el.dataset.change === 'txtype') { st.txt = el.value; const box = $('#txList'); if (box) box.innerHTML = txListHtml(); }
  if (el.dataset && el.dataset.change === 'theme') {
    applyTheme(el.value);
    api('settings.save', { json: { values: { theme: el.value } } }).catch(() => {});
  }
});
document.addEventListener('input', (e) => {
  const el = e.target;
  if (el.dataset && el.dataset.input === 'txsearch') { st.txq = el.value; const box = $('#txList'); if (box) box.innerHTML = txListHtml(); }
  if (el.dataset && el.dataset.input === 'cash') {
    const out = $('#kembali');
    if (out) out.textContent = rp(Math.max(0, (Number(el.value) || 0) - Number(el.dataset.total || 0)));
  }
});

/* ---------- izin aplikasi ---------- */
const PERMS = [
  { key: 'notif', label: 'Notifikasi', desc: 'Pengingat agenda muncul di HP',
    check: async (P) => (await P.LocalNotifications.checkPermissions()).display,
    req: (P) => P.LocalNotifications.requestPermissions() },
  { key: 'loc', label: 'Lokasi', desc: 'Cuaca otomatis sesuai lokasi',
    check: async (P) => (await P.Geolocation.checkPermissions()).location,
    req: async (P) => {
      if (!P.Geolocation) throw new Error('Plugin lokasi belum terpasang di APK');
      const current = await P.Geolocation.checkPermissions();
      if (current.location === 'granted') return current;
      return P.Geolocation.requestPermissions();
    } },
  { key: 'cam', label: 'Kamera & galeri', desc: 'Unggah logo dan foto',
    check: async (P) => (await P.Camera.checkPermissions()).camera,
    req: (P) => P.Camera.requestPermissions({ permissions: ['camera', 'photos'] }) },
  { key: 'cal', label: 'Kalender', desc: 'Tambah agenda ke kalender HP',
    check: async (P) => {
      const c = P.CapacitorCalendar;
      if (!c) return 'plugin tidak ada';
      const r = c.checkAllPermissions ? await c.checkAllPermissions() : await c.checkWriteOnlyCalendarAccess();
      return r?.result ?? r?.writeOnlyCalendar ?? r?.calendar ?? JSON.stringify(r);
    },
    req: async (P) => {
      const c = P.CapacitorCalendar;
      if (!c) throw new Error('Plugin kalender belum terpasang di APK');
      return c.requestAllPermissions ? c.requestAllPermissions() : c.requestWriteOnlyCalendarAccess();
    } },
  { key: 'nfc', label: 'NFC', desc: 'Deteksi kartu dan baca UID (bukan saldo)',
    check: async (P) => {
      const n = P.CapacitorNfc || P.Nfc;
      if (!n) return 'plugin tidak ada';
      const supported = await n.isSupported();
      if (!supported?.supported) return 'perangkat tidak mendukung';
      const status = await n.getStatus();
      return status?.status === 'NFC_OK' ? 'tersedia' : status?.status || 'periksa NFC';
    },
    req: async (P) => {
      const n = P.CapacitorNfc || P.Nfc;
      if (!n) throw new Error('Plugin NFC belum terpasang di APK');
      const supported = await n.isSupported();
      if (!supported?.supported) throw new Error('HP ini tidak memiliki NFC');
      const status = await n.getStatus();
      if (status?.status !== 'NFC_OK') return n.showSettings();
      toast('NFC aktif. Gunakan tombol Kaitkan NFC pada kartu.');
      return status;
    } },
];
function permsView() {
  const native = !!window.Capacitor?.isNativePlatform?.();
  return `<button class="chip" data-act="go" data-tab="more" data-sub="">‹ Kembali</button><h2 class="page-title">Izin aplikasi</h2>
    ${glass(`<p class="muted small" style="margin:0">Izin dipakai untuk pengingat, cuaca otomatis, kalender, dan kartu NFC. Tekan <b>Minta</b> untuk memunculkan dialog. Kalau sudah ditolak, buka Pengaturan HP &gt; Aplikasi &gt; SERumah &gt; Izin.</p>`)}
    ${glass(PERMS.map((p) => `<div class="li"><div class="g"><b>${p.label}</b><small>${p.desc}</small></div>
      <span class="pill" id="perm-${p.key}">memeriksa...</span>${p.req ? `<button class="chip" data-act="permreq" data-key="${p.key}">Minta</button>` : ''}</div>`).join(''))}
    <p class="muted small">${native ? 'Mode APK: izin diminta lewat sistem Android.' : 'Mode browser: izin mengikuti pengaturan situs di browser.'}</p>`;
}
async function refreshPermStatus() {
  const P = window.Capacitor?.Plugins || {};
  for (const p of PERMS) {
    const el = document.getElementById('perm-' + p.key);
    if (!el) continue;
    try {
      const raw = await p.check(P);
      const v = typeof raw === 'string' ? raw : String(raw ?? 'belum tersedia');
      const ok = ['granted', 'tersedia', 'true', 'granted'].includes(v.toLowerCase());
      el.textContent = ok ? (p.key === 'nfc' ? 'aktif' : 'diizinkan') : v === 'denied' ? 'ditolak' : v;
      el.className = 'pill ' + (ok ? 'ok' : (v === 'denied' || /tidak|plugin|denied/i.test(v) ? 'warn' : ''));
    } catch (_) {
      el.textContent = 'belum tersedia';
      el.className = 'pill warn';
    }
  }
}
function initNative() {
  const P = window.Capacitor?.Plugins || {};
  if (!window.Capacitor?.isNativePlatform?.()) return;
  document.documentElement.classList.add('native');
  try { P.StatusBar?.setOverlaysWebView?.({ overlay: true }); P.StatusBar?.setStyle?.({ style: 'DARK' }); } catch (_) {}
}
async function exportData() {
  const d = await api('data.all');
  const text = JSON.stringify(d, null, 2);
  const FS = window.Capacitor?.Plugins?.Filesystem;
  if (FS) {
    // APK: simpan ke folder Documents di HP (WebView tidak menangani unduhan blob)
    const path = `serumah-${today()}.json`;
    await FS.writeFile({ path, data: text, directory: 'DOCUMENTS', encoding: 'utf8', recursive: true });
    toast('Tersimpan di Documents: ' + path);
    return;
  }
  const blob = new Blob([text], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `serumah-${today()}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  toast('Data diunduh');
}
function openPayPreorder(id) {
  const p = st.D.preorders.find((x) => x.id == id);
  const sisa = Math.max(0, num(p.total) - num(p.dp));
  sheet(`<h3>Bayar pre order #${p.no}</h3>
    <p class="muted small">Total ${rp(p.total)} · dibayar ${rp(p.dp)} · sisa ${rp(sisa)}</p>
    <form data-submit="prepay" data-id="${id}">
      <label>Jumlah (Rp)<input name="amount" type="number" inputmode="numeric" data-type="num" value="${sisa}" required></label>
      <label>Masuk ke wallet<select name="wallet_id"><option value="">— tidak dicatat —</option>${walletOpts()}</select></label>
      <button class="btn" type="submit">Simpan pembayaran</button></form>`);
}
function userAdminView() {
  return sec('Akun pengguna (master)')
    + glass((st.D.users || []).map((u) => `<div class="li"><div class="g"><b>${esc(u.name || u.username)}</b><small>${esc(u.username)} · ${esc(u.role)}</small></div></div>`).join('') || '<p class="empty">Belum ada akun.</p>')
    + glass(`<form data-submit="usersave">
      <p class="muted small" style="margin:0">Isi username yang sudah ada untuk memperbarui akun (nama, peran, atau password).</p>
      <label>Username<input name="username" required maxlength="60" autocomplete="off"></label>
      <label>Nama<input name="name" maxlength="80"></label>
      <label>Peran<select name="role"><option value="user">Anggota (user)</option><option value="admin">Admin</option></select></label>
      <label>Password (min. 8 karakter)<input name="password" type="password" autocomplete="new-password"></label>
      <button class="btn" type="submit">Simpan akun</button></form>`);
}

/* ---------- tampilan & branding ---------- */
function brandHtml() {
  const s = st.D.settings;
  const logo = s.logo_url ? `<img class="logo-img" src="${esc(s.logo_url)}" alt="">` : '<div class="logo">SR</div>';
  return `${logo}<div><b>${esc(s.app_name || 'SERumah')}</b><small>${esc(s.family_name)}</small></div>`;
}
function applyAppearance(s) {
  const r = document.documentElement.style;
  if (s.accent) r.setProperty('--acc', s.accent);
  if (s.accent2) r.setProperty('--acc2', s.accent2);
  document.title = s.app_name || 'SERumah';
}
function masterView() {
  const s = st.D.settings;
  return sec('Tampilan (master)') + glass(`
    <label>Nama aplikasi<input id="mAppName" value="${esc(s.app_name)}" maxlength="80"></label>
    <div class="two-col"><label>Warna utama<input id="mAcc" type="color" value="${esc(s.accent)}"></label><label>Warna kedua<input id="mAcc2" type="color" value="${esc(s.accent2)}"></label></div>
    <button class="btn s ghost" data-act="saveAppear">Simpan tampilan</button>
    <label>Logo struk & header (PNG, JPG, WEBP, SVG)<input id="upLogo" type="file" accept=".png,.jpg,.jpeg,.webp,.svg"></label>
    <button class="btn s ghost" data-act="upload" data-purpose="logo">Unggah logo</button>
    <label>Ikon aplikasi (PNG, JPG, WEBP, SVG)<input id="upIcon" type="file" accept=".png,.jpg,.jpeg,.webp,.svg"></label>
    <button class="btn s ghost" data-act="upload" data-purpose="icon">Unggah ikon</button>
    <p class="muted small">Batas 10 MB per file. Ikon aplikasi baru terlihat setelah halaman dimuat ulang.</p>`);
}

/* ---------- pre order ---------- */
function posPreorder() {
  const itemsOf = (id) => st.D.preorder_items.filter((i) => i.preorder_id == id);
  const sisa = (p) => Math.max(0, num(p.total) - num(p.dp));
  const pre = st.D.preorders.map((p) => glass(`<div class="row-between"><div><b>#${p.no} · ${esc(p.customer_name || 'Tanpa pelanggan')}</b>
      <small class="muted">Ambil ${fdate(p.needed_date)} · ${itemsOf(p.id).map((i) => `${i.qty}x ${esc(i.name)}`).join(', ')}</small></div>
      <span class="pill ${p.status === 'batal' ? 'warn' : p.status === 'selesai' ? 'ok' : ''}">${esc(p.status)}</span></div>
      <div class="row-between" style="margin-top:8px"><small class="muted">Total ${rp(p.total)} · DP ${rp(p.dp)} · sisa ${rp(sisa(p))}</small>
      <div class="acts">${p.dp < p.total ? `<button class="chip" data-act="prepay" data-id="${p.id}">Bayar</button>` : ''}<button class="chip" data-act="porstatus" data-id="${p.id}">Status</button><button class="chip" data-act="editpre" data-id="${p.id}">Ubah</button><button class="chip" data-act="del" data-entity="preorders" data-id="${p.id}">Hapus</button></div></div>`));
  const cust = st.D.customers.map((c) => `<div class="li"><span class="tx-ic">${ic('book', 16)}</span><div class="g" data-act="edit" data-entity="customers" data-id="${c.id}"><b>${esc(c.name)}</b><small>${esc(c.phone || '-')}${c.address ? ' · ' + esc(c.address) : ''}</small></div></div>`);
  return sec('Pre order', `<button class="btn s" data-act="newpre">+ Pre order</button>`)
    + (pre.join('') || glass('<p class="empty">Belum ada pre order.</p>'))
    + sec('Daftar pelanggan', `<button class="btn s" data-act="new" data-entity="customers">+ Pelanggan</button>`)
    + glass(cust.join('') || '<p class="empty">Belum ada pelanggan.</p>');
}
function openPreorder(id) {
  const p = id ? st.D.preorders.find((x) => x.id == id) : null;
  const its = id ? st.D.preorder_items.filter((i) => i.preorder_id == id) : [];
  const qtyOf = (pid) => its.find((i) => i.product_id == pid)?.qty || '';
  const custs = st.D.customers.map((c) => `<option value="${c.id}" ${p && p.customer_id == c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
  sheet(`<h3>${id ? 'Ubah pre order' : 'Pre order baru'}</h3>
    <form data-submit="preorder" data-id="${id || 0}">
      <label>Pelanggan<select name="customer_id"><option value="">— pilih —</option>${custs}</select></label>
      <p class="muted small" style="margin:4px 0 0">Belum ada? Tambah dulu di bagian Daftar pelanggan.</p>
      <div class="two-col"><label>Tanggal ambil<input name="needed_date" type="date" value="${p ? p.needed_date : today()}" required></label>
      <label>DP (Rp)<input name="dp" type="number" inputmode="numeric" data-type="num" value="${p ? p.dp : 0}"></label></div>
      <h3 style="margin-top:14px">Menu & jumlah</h3>
      ${st.D.pos_products.filter((x) => x.active).map((x) => `<div class="li"><div class="g"><b>${esc(x.name)}</b><small>${rp(x.price)}</small></div><input name="q_${x.id}" type="number" inputmode="numeric" data-type="num" min="0" value="${qtyOf(x.id)}" style="width:84px"></div>`).join('')}
      <label>Catatan<textarea name="note" rows="2">${esc(p ? p.note : '')}</textarea></label>
      <button class="btn" type="submit">Simpan pre order</button></form>`);
}
function openStatus(id) {
  sheet(`<h3>Ubah status</h3>${['baru', 'diproses', 'siap', 'selesai', 'batal'].map((s) => `<button class="mi" data-act="porset" data-id="${id}" data-s="${s}"><span class="ic-tile">${ic('check', 18)}</span><div><b>${s}</b></div></button>`).join('')}`);
}

/* ---------- izin, pengingat, lokasi ---------- */
async function requestPermissions() {
  // Dipanggil saat login berhasil. Di APK memunculkan dialog izin Android; di browser memakai API web.
  const P = window.Capacitor?.Plugins || {};
  const run = async (fn) => { try { await fn(); } catch (_) { /* izin tidak tersedia di platform ini */ } };
  if (P.LocalNotifications) await run(() => P.LocalNotifications.requestPermissions());
  if (P.Camera) await run(() => P.Camera.requestPermissions({ permissions: ['camera', 'photos'] }));
  if (P.Geolocation) await run(() => P.Geolocation.requestPermissions());
  if (P.CapacitorCalendar) {
    const c = P.CapacitorCalendar;
    await run(() => (c.requestAllPermissions ? c.requestAllPermissions() : c.requestWriteOnlyCalendarAccess()));
  }
  if ('Notification' in window && Notification.permission === 'default') await run(() => Notification.requestPermission());
}
function downloadIcs(a) {
  const start = new Date(`${a.date}T${a.time || '09:00'}:00`);
  const end = new Date(start.getTime() + 3600000);
  const f = (d) => d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
  const ics = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//SERumah//ID', 'BEGIN:VEVENT',
    `UID:serumah-${a.id}@satuproyeksi.com`, `DTSTAMP:${f(new Date())}`, `DTSTART:${f(start)}`, `DTEND:${f(end)}`,
    `SUMMARY:${a.title}`, `DESCRIPTION:${a.category || ''}`, 'END:VEVENT', 'END:VCALENDAR'].join('\r\n');
  const url = URL.createObjectURL(new Blob([ics], { type: 'text/calendar' }));
  const link = document.createElement('a');
  link.href = url; link.download = `agenda-${a.id}.ics`;
  document.body.appendChild(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
async function calAdd(id) {
  const a = st.D.agenda.find((x) => x.id == id);
  if (!a) return;
  const C = window.Capacitor?.Plugins?.CapacitorCalendar;
  if (!C) { downloadIcs(a); closeSheet(); toast('Plugin kalender belum terpasang; berkas .ics diunduh'); return; }
  const permission = C.checkAllPermissions ? await C.checkAllPermissions() : null;
  const states = Object.values(permission?.result || {}).map(String);
  if (states.length && !states.includes('granted')) {
    const requested = C.requestWriteOnlyCalendarAccess ? await C.requestWriteOnlyCalendarAccess() : await C.requestAllPermissions();
    if (requested?.result !== 'granted' && !Object.values(requested?.result || {}).includes('granted')) {
      throw new Error('Izin kalender belum diberikan. Aktifkan izin Kalender di Pengaturan Android.');
    }
  }
  const start = new Date(`${a.date}T${a.time || '09:00'}:00`).getTime();
  await C.createEvent({ title: a.title, description: a.category || '', startDate: start, endDate: start + 3600000 });
  closeSheet();
  toast('Agenda ditambahkan ke kalender HP');
}
async function nfcLink(walletId, after) {
  // Membaca UID saja. Kartu uang elektronik memakai proteksi/protokol khusus;
  // UID tidak sama dengan saldo dan tidak dapat dipakai untuk mengambil saldo.
  const P = window.Capacitor?.Plugins || {};
  const N = P.CapacitorNfc || P.Nfc;
  const saveUid = async (uid) => {
    await api('crud.save', { json: { entity: 'wallets', data: { id: walletId, card_uid: String(uid) } } });
    toast('UID kartu terbaca: ' + uid);
    await refresh();
    if (after) after(uid);
  };
  if (N) {
    const supported = await N.isSupported();
    if (!supported?.supported) throw new Error('HP ini tidak memiliki NFC.');
    const status = await N.getStatus();
    if (status?.status !== 'NFC_OK') {
      await N.showSettings();
      throw new Error('Aktifkan NFC di pengaturan HP, lalu coba lagi.');
    }
    toast('Dekatkan kartu ke bagian belakang HP...');
    let done = false;
    let handle;
    handle = await N.addListener('nfcEvent', async (ev) => {
      const rawId = ev?.tag?.id || ev?.nfcTag?.id || ev?.id;
      if (!rawId || done) return;
      done = true;
      const uid = Array.isArray(rawId)
        ? rawId.map((b) => Number(b).toString(16).padStart(2, '0')).join(':').toUpperCase()
        : String(rawId);
      try { await N.stopScanning(); } catch (_) {}
      try { await handle?.remove?.(); } catch (_) {}
      await saveUid(uid);
    });
    try { await N.startScanning(); }
    catch (err) { try { await handle?.remove?.(); } catch (_) {} throw err; }
    return;
  }
  if ('NDEFReader' in window && window.isSecureContext) {
    const reader = new NDEFReader();
    await reader.scan();
    let done = false;
    reader.onreading = (ev) => { if (done) return; done = true; saveUid(ev.serialNumber || 'tag'); };
    toast('Dekatkan kartu ke HP...');
    return;
  }
  throw new Error('Plugin NFC belum tersedia. Build ulang APK setelah dependensi NFC ditambahkan.');
}

const reminded = new Set(JSON.parse(localStorage.getItem('sr_reminded') || '[]'));
function reminderItems() {
  const now = Date.now();
  return st.D.agenda.filter((a) => !a.done && a.time)
    .map((a) => ({ a, at: new Date(`${a.date}T${a.time}:00`) }))
    .filter((x) => x.at.getTime() > now - 60000);
}
async function scheduleReminders() {
  const LN = window.Capacitor?.Plugins?.LocalNotifications;
  if (!LN || !st.D) return;
  if ((await LN.checkPermissions().catch(() => ({ display: 'denied' }))).display !== 'granted') return;
  try {
    await LN.cancel({ notifications: st.D.agenda.map((a) => ({ id: 100000 + Number(a.id) })) }).catch(() => {});
    const list = reminderItems().filter((x) => x.at.getTime() > Date.now()).map(({ a, at }) => ({
      id: 100000 + Number(a.id),
      title: 'Pengingat: ' + a.title,
      body: (a.category || 'Agenda') + (a.amount ? ' · ' + rp(a.amount) : ''),
      schedule: { at, allowWhileIdle: true },
    }));
    if (list.length) await LN.schedule({ notifications: list });
  } catch (_) { /* jadwal gagal: pengingat web tetap berjalan saat halaman terbuka */ }
}
function checkWebReminders() {
  if (window.Capacitor?.Plugins?.LocalNotifications || !st.D) return;
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  const now = Date.now();
  reminderItems().forEach(({ a, at }) => {
    const key = a.id + '-' + at.getTime();
    if (at.getTime() <= now && !reminded.has(key)) {
      reminded.add(key);
      new Notification('Pengingat: ' + a.title, { body: a.category || 'Agenda' });
      localStorage.setItem('sr_reminded', JSON.stringify([...reminded].slice(-200)));
    }
  });
}
setInterval(checkWebReminders, 30000);
function getPosition() {
  return new Promise((res, rej) => {
    const P = window.Capacitor?.Plugins;
    if (P?.Geolocation) {
      (async () => {
        const permission = await P.Geolocation.checkPermissions();
        if (permission.location !== 'granted') await P.Geolocation.requestPermissions();
        return P.Geolocation.getCurrentPosition({ timeout: 15000, maximumAge: 600000, enableHighAccuracy: false });
      })().then(res, rej);
      return;
    }
    if (!navigator.geolocation) { rej(new Error('Browser tidak mendukung lokasi')); return; }
    navigator.geolocation.getCurrentPosition(res, rej, { timeout: 10000, maximumAge: 600000 });
  });
}
async function applyLocation(p) {
  st.loc = { lat: p.coords.latitude.toFixed(4), lon: p.coords.longitude.toFixed(4) };
  localStorage.setItem('sr_loc', JSON.stringify(st.loc));
  st.W = await api('weather', { extra: `&lat=${st.loc.lat}&lon=${st.loc.lon}` });
  render();
}
async function locateMe(quiet = false) {
  try {
    await applyLocation(await getPosition());
    if (!quiet) toast('Cuaca diperbarui untuk lokasimu');
  } catch (err) {
    if (quiet) return;
    toast(err.code === 1 ? 'Izin lokasi ditolak. Aktifkan lewat pengaturan browser/HP.' : 'Lokasi belum bisa diambil: ' + (err.message || 'coba lagi'));
  }
}
setInterval(() => { if (st.user) locateMe(true); }, 30 * 60 * 1000);

/* ---------- boot ---------- */
(async function boot() {
  applyTheme('auto');
  initNative();
  if ('serviceWorker' in navigator && !window.Capacitor?.isNativePlatform?.()) navigator.serviceWorker.register('sw.js').catch(() => {});
  try {
    const me = await api('auth.me');
    st.csrf = me.csrf;
    if (!me.auth) return renderLogin();
    st.user = me.user;
    try { st.loc = JSON.parse(localStorage.getItem('sr_loc') || 'null'); } catch (_) { st.loc = null; }
    await refresh();
    locateMe(true);
  } catch (err) {
    $('#app').innerHTML = `<div class="login-wrap"><div class="glass login-card"><p class="err">${esc(err.message)}</p><a class="btn" href="index.php">Muat ulang</a></div></div>`;
  }
})();
})();
