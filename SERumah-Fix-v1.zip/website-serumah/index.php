<?php
declare(strict_types=1);

require __DIR__ . '/includes/bootstrap.php';
send_security_headers();
$cfg = settings_map();
$appName = htmlspecialchars($cfg['app_name'] ?? 'SERumah', ENT_QUOTES);
$accent = preg_match('/^#[0-9a-fA-F]{6}$/', $cfg['accent'] ?? '') ? $cfg['accent'] : '#9a7412';
$accent2 = preg_match('/^#[0-9a-fA-F]{6}$/', $cfg['accent2'] ?? '') ? $cfg['accent2'] : '#2c5b3c';
$icon = !empty($cfg['icon_url']) ? htmlspecialchars($cfg['icon_url'], ENT_QUOTES) : 'assets/img/icon-192.png';
$iconType = str_ends_with($icon, '.svg') ? 'image/svg+xml' : (str_ends_with($icon, '.png') ? 'image/png' : 'image/*');
?>
<!DOCTYPE html>
<html lang="id" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#2c5b3c">
<meta name="robots" content="noindex,nofollow">
<title><?= $appName ?></title>
<link rel="icon" type="<?= $iconType ?>" href="<?= $icon ?>">
<link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon-180.png">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap">
<link rel="manifest" href="manifest.webmanifest">
<meta name="apple-mobile-web-app-capable" content="yes">
<link rel="stylesheet" href="assets/css/app.css">
<style>:root{--acc:<?= $accent ?>;--acc2:<?= $accent2 ?>}</style>
</head>
<body>
<noscript><p style="padding:20px">SERumah membutuhkan JavaScript.</p></noscript>
<div id="app"></div>
<script src="assets/js/app.js" defer></script>
</body>
</html>
