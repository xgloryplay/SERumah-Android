<?php
declare(strict_types=1);

function current_user(): array
{
    $st = db()->prepare('SELECT id, username, name, role FROM users WHERE id = ?');
    $st->execute([(int)($_SESSION['uid'] ?? 0)]);
    return $st->fetch() ?: [];
}

function login_user(array $b): array
{
    $pdo = db();
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0';
    $c = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE ip = ? AND ok = 0 AND at > ?');
    $c->execute([$ip, time() - 900]);
    if ((int)$c->fetchColumn() >= 5) {
        json_out(['error' => 'Terlalu banyak percobaan. Coba lagi dalam 15 menit.'], 429);
    }
    $username = strtolower(s($b['username'] ?? '', 60));
    $pass = (string)($b['password'] ?? '');
    $st = $pdo->prepare('SELECT * FROM users WHERE username = ?');
    $st->execute([$username]);
    $u = $st->fetch();
    $ok = $u && $pass !== '' && password_verify($pass, $u['password_hash']);
    $pdo->prepare('INSERT INTO login_attempts (ip, ok, at) VALUES (?,?,?)')->execute([$ip, $ok ? 1 : 0, time()]);
    if (!$ok) {
        usleep(400000);
        json_out(['error' => 'Username atau password salah'], 401);
    }
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    $pdo->prepare('DELETE FROM login_attempts WHERE ip = ?')->execute([$ip]);
    return ['user' => ['id' => (int)$u['id'], 'username' => $u['username'], 'name' => $u['name'], 'role' => $u['role']]];
}

function logout_user(): void
{
    $_SESSION = [];
    session_destroy();
}

function change_password(array $b): void
{
    $pdo = db();
    $st = $pdo->prepare('SELECT * FROM users WHERE id = ?');
    $st->execute([(int)$_SESSION['uid']]);
    $u = $st->fetch();
    if (!$u || !password_verify((string)($b['current'] ?? ''), $u['password_hash'])) {
        throw new RuntimeException('Password sekarang salah');
    }
    $new = (string)($b['next'] ?? '');
    if (strlen($new) < 8) {
        throw new RuntimeException('Password baru minimal 8 karakter');
    }
    $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), (int)$u['id']]);
}

function current_role(): string
{
    $st = db()->prepare('SELECT role FROM users WHERE id = ?');
    $st->execute([(int)($_SESSION['uid'] ?? 0)]);
    return (string)($st->fetchColumn() ?: 'user');
}

function require_master(string $msg = 'Hanya akun master yang bisa mengubah tampilan'): void
{
    if (current_role() !== 'master') {
        throw new RuntimeException($msg);
    }
}
