<?php
declare(strict_types=1);

const ROOT_DIR = __DIR__ . '/..';
const DATA_DIR = ROOT_DIR . '/data';
const SCHEMA_VERSION = 5;
const SESSION_IDLE = 28800;

require_once __DIR__ . '/schema.php';

function is_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
}

function send_security_headers(): void
{
    header_remove('X-Powered-By');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(self), microphone=(), geolocation=(self)');
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'");
    if (is_https()) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

function start_session(): void
{
    session_name('SRSESS');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => is_https(),
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
    if (!empty($_SESSION['last']) && time() - (int)$_SESSION['last'] > SESSION_IDLE) {
        $_SESSION = [];
        session_regenerate_id(true);
    }
    $_SESSION['last'] = time();
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    if (!is_dir(DATA_DIR) && !mkdir(DATA_DIR, 0750, true) && !is_dir(DATA_DIR)) {
        throw new RuntimeException('Folder data tidak bisa dibuat');
    }
    $pdo = new PDO('sqlite:' . DATA_DIR . '/serumah.sqlite', null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
    migrate($pdo);
    return $pdo;
}

function migrate(PDO $pdo): void
{
    $version = (int)$pdo->query('PRAGMA user_version')->fetchColumn();
    if ($version >= SCHEMA_VERSION) {
        return;
    }
    $pdo->beginTransaction();
    try {
        if ($version < 1) {
            $pdo->exec(SCHEMA_SQL);
            seed_defaults($pdo);
        }
        if ($version < 2) {
            $pdo->exec(SCHEMA_V2_SQL);
            seed_v2($pdo);
        }
        if ($version < 3) {
            $pdo->exec('ALTER TABLE wallets ADD COLUMN card_uid TEXT');
        }
        if ($version < 4) {
            $pdo->exec('ALTER TABLE categories ADD COLUMN alloc_pct INTEGER NOT NULL DEFAULT 0');
        }
        if ($version < 5) {
            $pdo->exec('ALTER TABLE preorders ADD COLUMN stock_done INTEGER NOT NULL DEFAULT 0');
        }
        $pdo->exec('PRAGMA user_version = ' . SCHEMA_VERSION);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function json_out($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}

function body_json(): array
{
    $j = json_decode((string)file_get_contents('php://input'), true);
    return is_array($j) ? $j : [];
}

function post_only(string $method): void
{
    if ($method !== 'POST') {
        json_out(['error' => 'Metode tidak diizinkan'], 405);
    }
}

function require_login(): void
{
    if (empty($_SESSION['uid'])) {
        json_out(['error' => 'Sesi berakhir, silakan login lagi'], 401);
    }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function rotate_csrf(): string
{
    unset($_SESSION['csrf']);
    return csrf_token();
}

function require_csrf(): void
{
    $sent = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (empty($_SESSION['csrf']) || $sent === '' || !hash_equals($_SESSION['csrf'], $sent)) {
        json_out(['error' => 'Token keamanan tidak valid. Muat ulang halaman.'], 419);
    }
}

function s($v, int $max = 200): string
{
    return mb_substr(trim((string)($v ?? '')), 0, $max);
}

function valid_date($v): bool
{
    $d = DateTime::createFromFormat('Y-m-d', (string)$v);
    return $d !== false && $d->format('Y-m-d') === (string)$v;
}

function settings_map(): array
{
    $o = [];
    foreach (db()->query('SELECT k, v FROM settings')->fetchAll() as $r) {
        $o[$r['k']] = $r['v'];
    }
    return $o;
}
