<?php
declare(strict_types=1);

function http_get(string $url): ?string
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 8,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($raw !== false && $code === 200) ? (string)$raw : null;
}

// Kode cuaca WMO -> [label, ikon]
function wmo(int $c): array
{
    return match (true) {
        $c === 0 => ['Cerah', 'sun'],
        $c >= 1 && $c <= 2 => ['Cerah berawan', 'cloud'],
        $c === 3 => ['Berawan', 'cloud'],
        $c === 45 || $c === 48 => ['Berkabut', 'fog'],
        $c >= 51 && $c <= 57 => ['Gerimis', 'rain'],
        $c >= 61 && $c <= 67 => ['Hujan', 'rain'],
        $c >= 71 && $c <= 77 => ['Salju', 'snow'],
        $c >= 80 && $c <= 82 => ['Hujan lebat', 'rain'],
        $c >= 85 && $c <= 86 => ['Salju', 'snow'],
        $c >= 95 => ['Badai petir', 'storm'],
        default => ['Berawan', 'cloud'],
    };
}

function weather_at(float $lat, float $lon): array
{
    if (!is_dir(DATA_DIR)) {
        mkdir(DATA_DIR, 0750, true);
    }
    $file = DATA_DIR . '/wx_' . md5(round($lat, 3) . ',' . round($lon, 3)) . '.json';
    if (is_file($file) && time() - filemtime($file) < 1800) {
        $cached = json_decode((string)file_get_contents($file), true);
        if (is_array($cached)) {
            return $cached;
        }
    }
    $url = 'https://api.open-meteo.com/v1/forecast?' . http_build_query([
        'latitude' => $lat,
        'longitude' => $lon,
        'current' => 'temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m',
        'daily' => 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max',
        'timezone' => 'auto',
        'forecast_days' => 5,
    ]);
    $raw = http_get($url);
    $j = $raw ? json_decode($raw, true) : null;
    if (!is_array($j) || !isset($j['current'])) {
        throw new RuntimeException('Data cuaca belum bisa diambil');
    }
    $cur = $j['current'];
    [$label, $icon] = wmo((int)$cur['weather_code']);
    $daily = [];
    $d = $j['daily'] ?? [];
    foreach (($d['time'] ?? []) as $i => $date) {
        [$l2, $i2] = wmo((int)$d['weather_code'][$i]);
        $daily[] = [
            'date' => $date,
            'label' => $l2,
            'icon' => $i2,
            'max' => (int)round((float)$d['temperature_2m_max'][$i]),
            'min' => (int)round((float)$d['temperature_2m_min'][$i]),
            'rain' => (int)($d['precipitation_probability_max'][$i] ?? 0),
        ];
    }
    $out = [
        'current' => [
            'temp' => (int)round((float)$cur['temperature_2m']),
            'feels' => (int)round((float)$cur['apparent_temperature']),
            'humidity' => (int)$cur['relative_humidity_2m'],
            'wind' => (int)round((float)$cur['wind_speed_10m']),
            'label' => $label,
            'icon' => $icon,
        ],
        'daily' => $daily,
    ];
    @file_put_contents($file, json_encode($out));
    return $out;
}

function weather_for_settings(): array
{
    $s = settings_map();
    return ['name' => $s['weather_name'] ?? 'Pontianak', 'data' => weather_at((float)$s['weather_lat'], (float)$s['weather_lon'])];
}

function geocode(string $q): array
{
    $q = trim(mb_substr($q, 0, 80));
    if (mb_strlen($q) < 2) {
        return [];
    }
    $raw = http_get('https://geocoding-api.open-meteo.com/v1/search?' . http_build_query(['name' => $q, 'count' => 5, 'language' => 'id', 'format' => 'json']));
    if ($raw === null) {
        throw new RuntimeException('Pencarian lokasi tidak tersedia');
    }
    $j = json_decode($raw, true);
    return array_map(fn($r) => [
        'name' => $r['name'],
        'region' => $r['admin1'] ?? '',
        'country' => $r['country'] ?? '',
        'lat' => $r['latitude'],
        'lon' => $r['longitude'],
    ], $j['results'] ?? []);
}
