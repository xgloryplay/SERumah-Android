<?php
declare(strict_types=1);

function bundle(): array
{
    $pdo = db();
    $m = date('Y-m');
    $wallets = $pdo->query("SELECT w.*, (w.start_balance
        + COALESCE((SELECT SUM(CASE WHEN t.type = 'in' THEN t.amount WHEN t.type = 'out' THEN -t.amount ELSE 0 END) FROM transactions t WHERE t.wallet_id = w.id), 0)
        - COALESCE((SELECT SUM(t.amount) FROM transactions t WHERE t.type = 'transfer' AND t.wallet_id = w.id), 0)
        + COALESCE((SELECT SUM(t.amount) FROM transactions t WHERE t.type = 'transfer' AND t.to_wallet_id = w.id), 0)) AS balance
        FROM wallets w ORDER BY w.id")->fetchAll();
    $cst = $pdo->prepare("SELECT c.*, COALESCE((SELECT SUM(t.amount) FROM transactions t WHERE t.category_id = c.id AND t.type = 'out' AND substr(t.date, 1, 7) = ?), 0) AS spent FROM categories c ORDER BY c.id");
    $cst->execute([$m]);
    return [
        'user' => current_user(),
        'settings' => settings_map(),
        'wallets' => $wallets,
        'categories' => $cst->fetchAll(),
        'transactions' => $pdo->query('SELECT * FROM transactions ORDER BY date DESC, id DESC LIMIT 1500')->fetchAll(),
        'recurring' => $pdo->query('SELECT * FROM recurring ORDER BY next_date')->fetchAll(),
        'debts' => $pdo->query('SELECT d.*, COALESCE((SELECT SUM(p.amount) FROM debt_payments p WHERE p.debt_id = d.id), 0) AS paid FROM debts d ORDER BY d.id DESC')->fetchAll(),
        'goals' => $pdo->query('SELECT g.*, COALESCE((SELECT SUM(e.amount) FROM goal_entries e WHERE e.goal_id = g.id), 0) AS saved FROM goals g ORDER BY g.id')->fetchAll(),
        'assets' => $pdo->query('SELECT *, ROUND(qty * current_price) AS value FROM assets ORDER BY id DESC')->fetchAll(),
        'agenda' => $pdo->query('SELECT * FROM agenda ORDER BY date, id')->fetchAll(),
        'customers' => $pdo->query('SELECT * FROM customers ORDER BY name')->fetchAll(),
        'users' => users_list(),
        'preorders' => $pdo->query('SELECT p.*, c.name AS customer_name FROM preorders p LEFT JOIN customers c ON c.id = p.customer_id ORDER BY p.id DESC LIMIT 300')->fetchAll(),
        'preorder_items' => $pdo->query('SELECT i.* FROM preorder_items i JOIN (SELECT id FROM preorders ORDER BY id DESC LIMIT 300) p ON p.id = i.preorder_id')->fetchAll(),
        'journal' => $pdo->query('SELECT * FROM journal ORDER BY date DESC, id DESC')->fetchAll(),
        'pos_ingredients' => $pdo->query('SELECT * FROM pos_ingredients ORDER BY id')->fetchAll(),
        'pos_products' => $pdo->query('SELECT * FROM pos_products ORDER BY id')->fetchAll(),
        'pos_recipes' => $pdo->query('SELECT * FROM pos_recipes')->fetchAll(),
        'pos_purchases' => $pdo->query('SELECT p.*, i.name AS ingredient_name FROM pos_purchases p LEFT JOIN pos_ingredients i ON i.id = p.ingredient_id ORDER BY p.id DESC LIMIT 100')->fetchAll(),
        'pos_sales' => $pdo->query('SELECT * FROM pos_sales ORDER BY id DESC LIMIT 200')->fetchAll(),
        'pos_sale_items' => $pdo->query('SELECT i.* FROM pos_sale_items i JOIN (SELECT id FROM pos_sales ORDER BY id DESC LIMIT 200) s ON s.id = i.sale_id')->fetchAll(),
    ];
}

function add_months_or_weeks(string $date, string $freq): string
{
    $d = new DateTime($date);
    $d->modify($freq === 'weekly' ? '+7 days' : '+1 month');
    return $d->format('Y-m-d');
}

// Jalankan transaksi rutin yang sudah jatuh tempo (idempotent lewat next_date)
function run_recurring(): void
{
    $pdo = db();
    $today = date('Y-m-d');
    $st = $pdo->prepare('SELECT * FROM recurring WHERE active = 1 AND next_date <= ?');
    $st->execute([$today]);
    foreach ($st->fetchAll() as $r) {
        $next = $r['next_date'];
        $n = 0;
        $pdo->beginTransaction();
        try {
            while ($next <= $today && $n++ < 120) {
                $pdo->prepare("INSERT INTO transactions (date, title, amount, type, wallet_id, category_id, note, source) VALUES (?,?,?,?,?,?,?,?)")
                    ->execute([$next, $r['title'], $r['amount'], $r['type'], $r['wallet_id'], $r['category_id'], 'Transaksi rutin', 'recurring']);
                $next = add_months_or_weeks($next, $r['frequency']);
            }
            $pdo->prepare('UPDATE recurring SET next_date = ? WHERE id = ?')->execute([$next, $r['id']]);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
}

function debt_pay(array $b): array
{
    $pdo = db();
    $debtId = (int)($b['debt_id'] ?? 0);
    $amount = (int)round((float)($b['amount'] ?? 0));
    $date = (string)($b['date'] ?? date('Y-m-d'));
    $wallet = ((int)($b['wallet_id'] ?? 0)) ?: null;
    if ($amount <= 0) {
        throw new RuntimeException('Nominal harus lebih dari 0');
    }
    if (!valid_date($date)) {
        throw new RuntimeException('Tanggal tidak valid');
    }
    $st = $pdo->prepare('SELECT * FROM debts WHERE id = ?');
    $st->execute([$debtId]);
    $debt = $st->fetch();
    if (!$debt) {
        throw new RuntimeException('Data tidak ditemukan');
    }
    $pdo->beginTransaction();
    try {
        $pdo->prepare('INSERT INTO debt_payments (debt_id, date, amount) VALUES (?,?,?)')->execute([$debtId, $date, $amount]);
        if ($wallet) {
            $isUtang = $debt['kind'] === 'utang';
            $pdo->prepare('INSERT INTO transactions (date, title, amount, type, wallet_id, note, source) VALUES (?,?,?,?,?,?,?)')
                ->execute([$date, ($isUtang ? 'Bayar utang: ' : 'Terima piutang: ') . $debt['party'], $amount, $isUtang ? 'out' : 'in', $wallet, '', 'debt']);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return ['ok' => true];
}

function goal_add(array $b): array
{
    $pdo = db();
    $goalId = (int)($b['goal_id'] ?? 0);
    $amount = (int)round((float)($b['amount'] ?? 0));
    $date = (string)($b['date'] ?? date('Y-m-d'));
    $wallet = ((int)($b['wallet_id'] ?? 0)) ?: null;
    if ($amount <= 0) {
        throw new RuntimeException('Nominal harus lebih dari 0');
    }
    if (!valid_date($date)) {
        throw new RuntimeException('Tanggal tidak valid');
    }
    $st = $pdo->prepare('SELECT * FROM goals WHERE id = ?');
    $st->execute([$goalId]);
    $goal = $st->fetch();
    if (!$goal) {
        throw new RuntimeException('Goal tidak ditemukan');
    }
    $pdo->beginTransaction();
    try {
        $pdo->prepare('INSERT INTO goal_entries (goal_id, date, amount) VALUES (?,?,?)')->execute([$goalId, $date, $amount]);
        if ($wallet) {
            $pdo->prepare('INSERT INTO transactions (date, title, amount, type, wallet_id, note, source) VALUES (?,?,?,?,?,?,?)')
                ->execute([$date, 'Tabungan: ' . $goal['name'], $amount, 'out', $wallet, '', 'goal']);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return ['ok' => true];
}

function settings_save(array $b): array
{
    $pdo = db();
    $vals = is_array($b['values'] ?? null) ? $b['values'] : [];
    foreach ($vals as $k => $v) {
        switch ($k) {
            case 'app_name':
            case 'accent':
            case 'accent2':
                require_master();
                if ($k !== 'app_name' && !preg_match('/^#[0-9a-fA-F]{6}$/', (string)$v)) {
                    throw new RuntimeException('Warna harus format #RRGGBB');
                }
                $v = s($v, 80);
                if ($v === '') {
                    throw new RuntimeException('Nama tidak boleh kosong');
                }
                break;
            case 'theme':
                if (!in_array($v, ['auto', 'light', 'dark'], true)) {
                    throw new RuntimeException('Tema tidak valid');
                }
                break;
            case 'family_name':
            case 'pos_name':
            case 'weather_name':
                $v = s($v, 80);
                if ($v === '') {
                    throw new RuntimeException('Nama tidak boleh kosong');
                }
                break;
            case 'weather_lat':
            case 'weather_lon':
                if (!is_numeric($v)) {
                    throw new RuntimeException('Koordinat tidak valid');
                }
                $v = (string)round((float)$v, 4);
                break;
            case 'low_stock':
                $v = (string)max(0, (int)$v);
                break;
            default:
                continue 2;
        }
        $pdo->prepare('INSERT INTO settings (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v')->execute([$k, (string)$v]);
    }
    return ['ok' => true];
}
