<?php
declare(strict_types=1);

const SCHEMA_SQL = <<<'SQL'
CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, name TEXT NOT NULL DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE login_attempts (id INTEGER PRIMARY KEY, ip TEXT NOT NULL, ok INTEGER NOT NULL, at INTEGER NOT NULL);
CREATE TABLE settings (k TEXT PRIMARY KEY, v TEXT NOT NULL DEFAULT '');
CREATE TABLE wallets (id INTEGER PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'bank', start_balance INTEGER NOT NULL DEFAULT 0, color TEXT NOT NULL DEFAULT '#c9a227', archived INTEGER NOT NULL DEFAULT 0);
CREATE TABLE categories (id INTEGER PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'out', budget INTEGER NOT NULL DEFAULT 0, color TEXT NOT NULL DEFAULT '#8b8478');
CREATE TABLE transactions (id INTEGER PRIMARY KEY, date TEXT NOT NULL, title TEXT NOT NULL, amount INTEGER NOT NULL, type TEXT NOT NULL CHECK (type IN ('in','out','transfer')), wallet_id INTEGER REFERENCES wallets(id) ON DELETE SET NULL, to_wallet_id INTEGER REFERENCES wallets(id) ON DELETE SET NULL, category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL, note TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT 'manual');
CREATE INDEX idx_tx_date ON transactions(date);
CREATE TABLE recurring (id INTEGER PRIMARY KEY, title TEXT NOT NULL, amount INTEGER NOT NULL, type TEXT NOT NULL CHECK (type IN ('in','out')), wallet_id INTEGER REFERENCES wallets(id) ON DELETE SET NULL, category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL, frequency TEXT NOT NULL DEFAULT 'monthly', next_date TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE debts (id INTEGER PRIMARY KEY, kind TEXT NOT NULL CHECK (kind IN ('utang','piutang')), party TEXT NOT NULL, amount INTEGER NOT NULL, due_date TEXT, note TEXT NOT NULL DEFAULT '');
CREATE TABLE debt_payments (id INTEGER PRIMARY KEY, debt_id INTEGER NOT NULL REFERENCES debts(id) ON DELETE CASCADE, date TEXT NOT NULL, amount INTEGER NOT NULL);
CREATE TABLE goals (id INTEGER PRIMARY KEY, name TEXT NOT NULL, target INTEGER NOT NULL, due_date TEXT, color TEXT NOT NULL DEFAULT '#5e9564');
CREATE TABLE goal_entries (id INTEGER PRIMARY KEY, goal_id INTEGER NOT NULL REFERENCES goals(id) ON DELETE CASCADE, date TEXT NOT NULL, amount INTEGER NOT NULL);
CREATE TABLE assets (id INTEGER PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'lainnya', qty REAL NOT NULL DEFAULT 1, buy_price INTEGER NOT NULL DEFAULT 0, current_price INTEGER NOT NULL DEFAULT 0, date_bought TEXT, note TEXT NOT NULL DEFAULT '');
CREATE TABLE agenda (id INTEGER PRIMARY KEY, date TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL DEFAULT '', kind TEXT NOT NULL DEFAULT 'tugas', amount INTEGER NOT NULL DEFAULT 0, done INTEGER NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT '');
CREATE TABLE journal (id INTEGER PRIMARY KEY, date TEXT NOT NULL, text TEXT NOT NULL);
CREATE TABLE pos_ingredients (id INTEGER PRIMARY KEY, name TEXT NOT NULL, total_g REAL NOT NULL DEFAULT 0, total_cost REAL NOT NULL DEFAULT 0, stock_g REAL NOT NULL DEFAULT 0);
CREATE TABLE pos_products (id INTEGER PRIMARY KEY, name TEXT NOT NULL, price INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE pos_recipes (product_id INTEGER NOT NULL REFERENCES pos_products(id) ON DELETE CASCADE, ingredient_id INTEGER NOT NULL REFERENCES pos_ingredients(id) ON DELETE CASCADE, grams REAL NOT NULL);
CREATE TABLE pos_purchases (id INTEGER PRIMARY KEY, date TEXT NOT NULL, ingredient_id INTEGER REFERENCES pos_ingredients(id) ON DELETE SET NULL, grams REAL NOT NULL, cost INTEGER NOT NULL);
CREATE TABLE pos_sales (id INTEGER PRIMARY KEY, no INTEGER NOT NULL, ts INTEGER NOT NULL, total INTEGER NOT NULL, hpp INTEGER NOT NULL, pay TEXT NOT NULL, cash INTEGER NOT NULL, wallet_id INTEGER REFERENCES wallets(id) ON DELETE SET NULL);
CREATE TABLE pos_sale_items (id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL REFERENCES pos_sales(id) ON DELETE CASCADE, product_id INTEGER, name TEXT NOT NULL, qty INTEGER NOT NULL, price INTEGER NOT NULL, hpp INTEGER NOT NULL);
CREATE TABLE imports (id INTEGER PRIMARY KEY, source TEXT NOT NULL, at INTEGER NOT NULL, summary TEXT NOT NULL);
SQL;

function seed_defaults(PDO $pdo): void
{
    $run = function (string $sql, array $p = []) use ($pdo): int {
        $st = $pdo->prepare($sql);
        $st->execute($p);
        return (int)$pdo->lastInsertId();
    };
    $run('INSERT INTO users (username, password_hash, name) VALUES (?,?,?)', ['serumah', password_hash('serumah', PASSWORD_DEFAULT), 'Keluarga']);
    foreach ([['theme', 'auto'], ['family_name', 'Keluarga Kita'], ['weather_name', 'Pontianak'], ['weather_lat', '-0.0263'], ['weather_lon', '109.3425'], ['pos_name', 'ES Factory'], ['low_stock', '500'], ['pos_no', '1']] as [$k, $v]) {
        $run('INSERT INTO settings (k, v) VALUES (?,?)', [$k, $v]);
    }
    $run("INSERT INTO wallets (name, type) VALUES ('Tunai','tunai'),('BCA','bank')");
    $run("INSERT INTO categories (name, kind, budget) VALUES ('Makan','out',1500000),('Transport','out',500000),('Belanja','out',1000000),('Tagihan','out',0),('Maintenance','out',0),('Hiburan','out',0),('Gaji','in',0),('Penjualan POS','in',0),('Belanja bahan','out',0),('Lainnya','out',0)");
    $run("INSERT INTO pos_ingredients (name, total_g, total_cost, stock_g) VALUES ('Gula pasir',1000,15000,1000),('Teh bubuk',250,25000,250),('Es batu',5000,20000,5000),('Sirup melon',1000,60000,1000)");
    $run("INSERT INTO pos_products (name, price) VALUES ('Es Teh Manis',5000),('Es Melon',8000)");
    $run("INSERT INTO pos_recipes (product_id, ingredient_id, grams) VALUES (1,2,3),(1,1,20),(1,3,150),(2,4,30),(2,3,150)");
}

const SCHEMA_V2_SQL = <<<'SQL'
ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user';
ALTER TABLE agenda ADD COLUMN time TEXT;
CREATE TABLE customers (id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '');
CREATE TABLE preorders (id INTEGER PRIMARY KEY, no INTEGER NOT NULL, customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL, needed_date TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'baru' CHECK (status IN ('baru','diproses','siap','selesai','batal')), total INTEGER NOT NULL DEFAULT 0, dp INTEGER NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL);
CREATE TABLE preorder_items (id INTEGER PRIMARY KEY, preorder_id INTEGER NOT NULL REFERENCES preorders(id) ON DELETE CASCADE, product_id INTEGER, name TEXT NOT NULL, qty INTEGER NOT NULL, price INTEGER NOT NULL);
SQL;

function seed_v2(PDO $pdo): void
{
    // Akun master: password disimpan sebagai hash (terenkripsi satu arah), bukan plaintext
    $pdo->prepare("UPDATE users SET role = 'admin' WHERE username = 'serumah'")->execute();
    $pdo->prepare("INSERT INTO users (username, password_hash, name, role) VALUES (?,?,?,?)")
        ->execute(['master', password_hash('s3rum4h', PASSWORD_DEFAULT), 'Master', 'master']);
    foreach ([['app_name', 'SERumah'], ['accent', '#9a7412'], ['accent2', '#2c5b3c'], ['logo_url', ''], ['icon_url', '']] as [$k, $v]) {
        $pdo->prepare('INSERT OR IGNORE INTO settings (k, v) VALUES (?, ?)')->execute([$k, $v]);
    }
}
