<?php
declare(strict_types=1);

// Pola deteksi kolom: [pola prioritas tinggi, pola umum]
const IMP_PATTERNS = [
    'amount' => ['/^(amount|amt|nominal|jumlah|nilai)$/', '/amount|nominal|jumlah|nilai|value|total|price|harga|sum/'],
    'title' => ['/^(title|name|nama|judul|item|label)$/', '/title|name|nama|judul|desc|item|label|keterangan/'],
    'party' => ['/^(party|person|pihak|kepada|nama)$/', '/party|person|pihak|kepada|contact/'],
    'date' => ['/^(date|tanggal|tgl)$/', '/date|tanggal|tgl|time|waktu|created/'],
    'due' => ['/due|jatuh|tempo/'],
    'type' => ['/^(type|tipe|jenis|kind|flow|direction|arah)$/', '/type|tipe|jenis|flow|direction/'],
    'wallet' => ['/^(wallet_id|account_id|wallet|account|akun|dompet|rekening)$/', '/wallet|account|akun|dompet|rekening/'],
    'to_wallet' => ['/^(to_wallet_id|to_account_id|to_wallet|to_account|tujuan)$/', '/to_wallet|to_account|tujuan/'],
    'category' => ['/^(category_id|category|kategori|kategori_id)$/', '/categor|kategori/'],
    'note' => ['/^(note|notes|catatan|memo|remark|deskripsi|description|detail)$/', '/note|catatan|memo|remark|desc|detail/'],
    'freq' => ['/freq|period|ulang|repeat|interval/'],
    'next' => ['/next|berikut/'],
    'target' => ['/^(target|target_amount|goal_amount|limit)$/', '/target|goal|limit/'],
    'saved' => ['/saved|terkumpul|progress|tabungan|current_amount/'],
    'paid' => ['/paid|dibayar|terbayar|repaid|sudah_bayar/'],
    'cost' => ['/^(cost|buy_price|purchase_price|harga_beli|beli)$/', '/cost|buy|beli|purchase/'],
    'value' => ['/^(value|current_value|current_price|market_value|nilai_sekarang)$/', '/value|nilai|current|sekarang|market/'],
    'qty' => ['/^(qty|quantity|units|lot|jumlah_unit)$/', '/qty|quantity|units/'],
    'done' => ['/^(done|is_done|completed|selesai|checked)$/', '/done|selesai|complete|checked/'],
    'text' => ['/^(text|content|isi|body)$/', '/text|content|isi|body/'],
    'active' => ['/^(active|aktif|is_active|enabled)$/'],
    'kind' => ['/^(kind|debt_type|jenis_utang)$/', '/kind|jenis/'],
    'balance' => ['/^(balance|saldo|current_balance|saldo_sekarang)$/', '/balance|saldo/'],
];

function import_upload(?array $file, string $dry): array
{
    if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Upload file gagal');
    }
    if ($file['size'] > 25 * 1024 * 1024) {
        throw new RuntimeException('Ukuran file maksimal 25 MB');
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['sqlite', 'sqlite3', 'db', 'json', 'csv'], true)) {
        throw new RuntimeException('Format harus .sqlite, .db, .json, atau .csv');
    }
    $tmp = DATA_DIR . '/import_' . bin2hex(random_bytes(6)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $tmp)) {
        throw new RuntimeException('Gagal menyimpan file sementara');
    }
    try {
        $tables = import_read($tmp, $ext, $file['name']);
        return import_apply($tables, $dry !== '0', basename($file['name']));
    } finally {
        @unlink($tmp);
    }
}

function import_read(string $path, string $ext, string $name): array
{
    $out = [];
    if (in_array($ext, ['sqlite', 'sqlite3', 'db'], true)) {
        $src = new PDO('sqlite:' . $path, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
        $names = $src->query("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($names as $t) {
            $q = '"' . str_replace('"', '""', (string)$t) . '"';
            $out[(string)$t] = $src->query("SELECT * FROM $q LIMIT 50000")->fetchAll();
        }
    } elseif ($ext === 'json') {
        $j = json_decode((string)file_get_contents($path), true);
        if (!is_array($j)) {
            throw new RuntimeException('File JSON tidak valid');
        }
        if (array_is_list($j)) {
            $out[pathinfo($name, PATHINFO_FILENAME)] = $j;
        } else {
            foreach ($j as $k => $v) {
                if (is_array($v)) {
                    $out[(string)$k] = array_is_list($v) ? $v : [];
                }
            }
        }
    } else {
        $h = fopen($path, 'r');
        $head = $h ? fgetcsv($h) : false;
        $rows = [];
        if ($head) {
            $head = array_map('trim', $head);
            while (($r = fgetcsv($h)) !== false) {
                if (count($r) === count($head)) {
                    $rows[] = array_combine($head, $r);
                }
            }
        }
        if ($h) {
            fclose($h);
        }
        $out[pathinfo($name, PATHINFO_FILENAME)] = $rows;
    }
    return $out;
}

function import_role(string $table): ?string
{
    $t = strtolower($table);
    if (preg_match('/payment|pembayaran|riwayat|history|log/', $t)) {
        return null;
    }
    $map = [
        'category' => '/categor|kategori/',
        'wallet' => '/wallet|account|akun|dompet|rekening|kantong/',
        'recurring' => '/recurr|rutin|berulang|langganan|subscription/',
        'debt' => '/debt|utang|hutang|piutang|loan|pinjam/',
        'goal' => '/goal|target|tabung|saving|celengan/',
        'asset' => '/asset|aset|invest|portofolio|portfolio/',
        'agenda' => '/agenda|reminder|tagihan|bill|task|tugas|schedule|event|kalender/',
        'journal' => '/journal|jurnal|diary|catatan|note/',
        'transaction' => '/trans|catat|expense|income|pengeluaran|pemasukan|record|entr|flow|kas/',
    ];
    foreach ($map as $role => $re) {
        if (preg_match($re, $t)) {
            return $role;
        }
    }
    return null;
}

function import_pick(array $cols, string $field): ?string
{
    foreach (IMP_PATTERNS[$field] ?? [] as $re) {
        foreach ($cols as $c) {
            if (preg_match($re, strtolower((string)$c))) {
                return (string)$c;
            }
        }
    }
    return null;
}

function imp_str($v): string
{
    return trim((string)($v ?? ''));
}

function imp_money($v): int
{
    if ($v === null || $v === '') {
        return 0;
    }
    if (is_numeric($v)) {
        return (int)round((float)$v);
    }
    $s = preg_replace('/[^0-9\-]/', '', (string)$v);
    return (int)($s === '' || $s === '-' ? 0 : $s);
}

function imp_date($v): string
{
    if ($v === null || $v === '') {
        return date('Y-m-d');
    }
    if (is_numeric($v)) {
        $n = (float)$v;
        if ($n > 1e11) {
            $n /= 1000;
        }
        if ($n > 1e9) {
            return date('Y-m-d', (int)$n);
        }
    }
    $t = strtotime((string)$v);
    return $t ? date('Y-m-d', $t) : date('Y-m-d');
}

function imp_type($v): string
{
    $x = strtolower(imp_str($v));
    if ($x === 'transfer') {
        return 'transfer';
    }
    if (in_array($x, ['in', 'income', 'masuk', 'pemasukan', 'credit', 'deposit', 'terima', 'pendapatan', '+'], true)) {
        return 'in';
    }
    return 'out';
}

function imp_bool($v, bool $default): bool
{
    if ($v === null || $v === '') {
        return $default;
    }
    return in_array(strtolower(imp_str($v)), ['1', 'true', 'yes', 'ya', 'y', 'done', 'lunas', 'selesai', 'paid', 'on'], true);
}

function imp_asset_type($v): string
{
    $x = strtolower(imp_str($v));
    $map = ['saham' => 'saham|stock|share', 'emas' => 'emas|gold', 'reksadana' => 'reksa|mutual|fund', 'properti' => 'properti|property|tanah|rumah|house|land', 'kendaraan' => 'mobil|motor|kendaraan|car|vehicle'];
    foreach ($map as $t => $re) {
        if (preg_match("/$re/", $x)) {
            return $t;
        }
    }
    return 'lainnya';
}

function ensure_named(string $table, string $name, array $extra = []): int
{
    $pdo = db();
    $st = $pdo->prepare("SELECT id FROM $table WHERE lower(name) = lower(?) LIMIT 1");
    $st->execute([$name]);
    $id = $st->fetchColumn();
    if ($id) {
        return (int)$id;
    }
    $data = array_merge(['name' => mb_substr($name, 0, 120)], $extra);
    $cols = array_keys($data);
    $pdo->prepare("INSERT INTO $table (" . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')')->execute(array_values($data));
    return (int)$pdo->lastInsertId();
}

function import_ref(array $row, ?string $col, string $role, array $names): ?int
{
    if ($col === null || !isset($row[$col]) || $row[$col] === '') {
        return null;
    }
    $raw = $row[$col];
    $key = (string)$raw;
    if (isset($names[$role][$key])) {
        $label = $names[$role][$key];
    } elseif (is_numeric($raw)) {
        return null;
    } else {
        $label = imp_str($raw);
    }
    return $role === 'wallet'
        ? ensure_named('wallets', $label, ['type' => 'bank'])
        : ensure_named('categories', $label, ['kind' => 'out']);
}

function import_apply(array $tables, bool $dry, string $source): array
{
    $pdo = db();
    $report = [];
    $warnings = [];
    $groups = [];
    foreach ($tables as $name => $rows) {
        $rows = array_values(array_filter((array)$rows, 'is_array'));
        $role = import_role((string)$name);
        $cols = $rows ? array_keys($rows[0]) : [];
        // Nama tabel tidak dikenali: tebak dari kolom (ada nominal + tanggal = transaksi)
        if (!$role && $cols && import_pick($cols, 'amount') && import_pick($cols, 'date') && !preg_match('/payment|pembayaran|riwayat|history|log/i', (string)$name)) {
            $role = 'transaction';
        }
        $map = [];
        if ($role) {
            foreach (array_keys(IMP_PATTERNS) as $f) {
                $map[$f] = import_pick($cols, $f);
            }
        }
        $used = array_values(array_filter($map));
        $report[$name] = [
            'role' => $role ?? 'dilewati',
            'rows' => count($rows),
            'kolom_terpetakan' => array_values(array_unique($used)),
            'kolom_tidak_terpakai' => array_values(array_diff(array_map('strval', $cols), $used, ['id'])),
        ];
        if (!$role) {
            if ($rows) {
                $warnings[] = "Tabel \"$name\" tidak dikenali dan dilewati.";
            }
            continue;
        }
        $groups[$role][] = ['name' => (string)$name, 'rows' => $rows, 'map' => $map];
    }

    $counts = array_fill_keys(['wallets', 'categories', 'transactions', 'recurring', 'debts', 'goals', 'assets', 'agenda', 'journal'], 0);
    $names = ['wallet' => [], 'category' => []];
    $sourceBalance = [];
    $pdo->beginTransaction();
    try {
        foreach (['wallet', 'category'] as $role) {
            foreach ($groups[$role] ?? [] as $g) {
                $hasId = $g['rows'] && array_key_exists('id', $g['rows'][0]);
                foreach ($g['rows'] as $r) {
                    $label = imp_str($g['map']['title'] ? ($r[$g['map']['title']] ?? '') : '');
                    if ($label === '') {
                        continue;
                    }
                    if ($hasId) {
                        $names[$role][(string)$r['id']] = $label;
                    }
                    if ($role === 'wallet') {
                        $wid = ensure_named('wallets', $label, ['type' => 'bank']);
                        if ($g['map']['balance'] && array_key_exists($g['map']['balance'], $r)) {
                            $sourceBalance[$wid] = imp_money($r[$g['map']['balance']]);
                        }
                        $counts['wallets']++;
                    } else {
                        ensure_named('categories', $label, ['kind' => 'out']);
                        $counts['categories']++;
                    }
                }
            }
        }

        foreach ($groups['transaction'] ?? [] as $g) {
            $m = $g['map'];
            foreach ($g['rows'] as $r) {
                $amt = imp_money($m['amount'] ? ($r[$m['amount']] ?? 0) : 0);
                if ($amt === 0) {
                    continue;
                }
                $type = $m['type'] ? imp_type($r[$m['type']] ?? '') : 'out';
                if ($type === 'transfer' && !$m['to_wallet']) {
                    $type = 'out';
                    $warnings[] = 'Transfer tanpa kolom tujuan diimpor sebagai pengeluaran: ' . imp_str($m['title'] ? ($r[$m['title']] ?? '') : '');
                }
                $wallet = import_ref($r, $m['wallet'], 'wallet', $names);
                $to = $type === 'transfer' ? import_ref($r, $m['to_wallet'], 'wallet', $names) : null;
                $cat = import_ref($r, $m['category'], 'category', $names);
                $title = imp_str($m['title'] ? ($r[$m['title']] ?? '') : '') ?: 'Transaksi impor';
                $date = imp_date($m['date'] ? ($r[$m['date']] ?? null) : null);
                $note = imp_str($m['note'] ? ($r[$m['note']] ?? '') : '');
                $pdo->prepare('INSERT INTO transactions (date, title, amount, type, wallet_id, to_wallet_id, category_id, note, source) VALUES (?,?,?,?,?,?,?,?,?)')
                    ->execute([$date, mb_substr($title, 0, 200), abs($amt), $type, $wallet, $to, $cat, mb_substr($note, 0, 2000), 'moneynest']);
                $counts['transactions']++;
            }
        }

        foreach ($sourceBalance as $wid => $bal) {
            $net = $pdo->prepare("SELECT (SELECT COALESCE(SUM(CASE WHEN t.type = 'in' THEN t.amount WHEN t.type = 'out' THEN -t.amount ELSE 0 END), 0) FROM transactions t WHERE t.wallet_id = :w)
                - (SELECT COALESCE(SUM(t.amount), 0) FROM transactions t WHERE t.type = 'transfer' AND t.wallet_id = :w)
                + (SELECT COALESCE(SUM(t.amount), 0) FROM transactions t WHERE t.type = 'transfer' AND t.to_wallet_id = :w)");
            $net->execute(['w' => $wid]);
            $pdo->prepare('UPDATE wallets SET start_balance = ? WHERE id = ?')->execute([$bal - (int)$net->fetchColumn(), $wid]);
        }
        if ($sourceBalance) {
            $warnings[] = 'Saldo awal wallet disesuaikan agar saldo akhir sama dengan saldo di sumber.';
        }

        foreach ($groups['recurring'] ?? [] as $g) {
            $m = $g['map'];
            foreach ($g['rows'] as $r) {
                $amt = abs(imp_money($m['amount'] ? ($r[$m['amount']] ?? 0) : 0));
                if (!$amt) {
                    continue;
                }
                $freq = preg_match('/week|minggu/i', imp_str($m['freq'] ? ($r[$m['freq']] ?? '') : '')) ? 'weekly' : 'monthly';
                $nextRaw = $m['next'] ? ($r[$m['next']] ?? null) : ($m['date'] ? ($r[$m['date']] ?? null) : null);
                $pdo->prepare('INSERT INTO recurring (title, amount, type, wallet_id, category_id, frequency, next_date, active) VALUES (?,?,?,?,?,?,?,?)')
                    ->execute([
                        mb_substr(imp_str($m['title'] ? ($r[$m['title']] ?? '') : '') ?: 'Rutin impor', 0, 200),
                        $amt,
                        $m['type'] ? imp_type($r[$m['type']] ?? '') : 'out',
                        import_ref($r, $m['wallet'], 'wallet', $names),
                        import_ref($r, $m['category'], 'category', $names),
                        $freq,
                        $nextRaw === null ? date('Y-m-d', strtotime('+1 month')) : imp_date($nextRaw),
                        imp_bool($m['active'] ? ($r[$m['active']] ?? null) : null, true) ? 1 : 0,
                    ]);
                $counts['recurring']++;
            }
        }

        foreach ($groups['debt'] ?? [] as $g) {
            $m = $g['map'];
            foreach ($g['rows'] as $r) {
                $amt = abs(imp_money($m['amount'] ? ($r[$m['amount']] ?? 0) : 0));
                if (!$amt) {
                    continue;
                }
                $kindRaw = strtolower(imp_str($m['kind'] ? ($r[$m['kind']] ?? '') : ''));
                $kind = preg_match('/piutang|receiv|lent|dipinjamkan|owed_to_me/', $kindRaw) ? 'piutang' : 'utang';
                $party = mb_substr(imp_str($m['party'] ? ($r[$m['party']] ?? '') : '') ?: (imp_str($m['title'] ? ($r[$m['title']] ?? '') : '') ?: 'Tanpa nama'), 0, 120);
                $due = $m['due'] ? ($r[$m['due']] ?? null) : null;
                $pdo->prepare('INSERT INTO debts (kind, party, amount, due_date, note) VALUES (?,?,?,?,?)')
                    ->execute([$kind, $party, $amt, $due === null || $due === '' ? null : imp_date($due), mb_substr(imp_str($m['note'] ? ($r[$m['note']] ?? '') : ''), 0, 2000)]);
                $debtId = (int)$pdo->lastInsertId();
                $paid = abs(imp_money($m['paid'] ? ($r[$m['paid']] ?? 0) : 0));
                if ($paid > 0) {
                    $pdo->prepare('INSERT INTO debt_payments (debt_id, date, amount) VALUES (?,?,?)')->execute([$debtId, date('Y-m-d'), min($paid, $amt)]);
                }
                $counts['debts']++;
            }
        }

        foreach ($groups['goal'] ?? [] as $g) {
            $m = $g['map'];
            foreach ($g['rows'] as $r) {
                $target = abs(imp_money($m['target'] ? ($r[$m['target']] ?? 0) : ($m['amount'] ? ($r[$m['amount']] ?? 0) : 0)));
                $name = imp_str($m['title'] ? ($r[$m['title']] ?? '') : '') ?: 'Goal impor';
                if (!$target) {
                    continue;
                }
                $due = $m['due'] ? ($r[$m['due']] ?? null) : null;
                $pdo->prepare('INSERT INTO goals (name, target, due_date) VALUES (?,?,?)')->execute([mb_substr($name, 0, 120), $target, $due === null || $due === '' ? null : imp_date($due)]);
                $gid = (int)$pdo->lastInsertId();
                $saved = abs(imp_money($m['saved'] ? ($r[$m['saved']] ?? 0) : 0));
                if ($saved > 0) {
                    $pdo->prepare('INSERT INTO goal_entries (goal_id, date, amount) VALUES (?,?,?)')->execute([$gid, date('Y-m-d'), $saved]);
                }
                $counts['goals']++;
            }
        }

        foreach ($groups['asset'] ?? [] as $g) {
            $m = $g['map'];
            foreach ($g['rows'] as $r) {
                $name = imp_str($m['title'] ? ($r[$m['title']] ?? '') : '') ?: 'Aset impor';
                $qty = $m['qty'] ? (float)($r[$m['qty']] ?? 1) : 1.0;
                $buy = abs(imp_money($m['cost'] ? ($r[$m['cost']] ?? 0) : ($m['amount'] ? ($r[$m['amount']] ?? 0) : 0)));
                $value = $m['value'] ? abs(imp_money($r[$m['value']] ?? 0)) : $buy;
                $bought = $m['date'] ? ($r[$m['date']] ?? null) : null;
                $pdo->prepare('INSERT INTO assets (name, type, qty, buy_price, current_price, date_bought) VALUES (?,?,?,?,?,?)')
                    ->execute([mb_substr($name, 0, 120), imp_asset_type($m['type'] ? ($r[$m['type']] ?? '') : ''), $qty ?: 1, $buy, $value, $bought === null ? null : imp_date($bought)]);
                $counts['assets']++;
            }
        }

        foreach ($groups['agenda'] ?? [] as $g) {
            $m = $g['map'];
            foreach ($g['rows'] as $r) {
                $title = imp_str($m['title'] ? ($r[$m['title']] ?? '') : '') ?: 'Agenda impor';
                $pdo->prepare('INSERT INTO agenda (date, title, category, kind, amount, done, note) VALUES (?,?,?,?,?,?,?)')
                    ->execute([
                        imp_date($m['date'] ? ($r[$m['date']] ?? null) : null),
                        mb_substr($title, 0, 200),
                        mb_substr(imp_str($m['category'] ? ($r[$m['category']] ?? '') : ''), 0, 120),
                        preg_match('/bill|tagihan/i', $g['name']) ? 'tagihan' : 'tugas',
                        abs(imp_money($m['amount'] ? ($r[$m['amount']] ?? 0) : 0)),
                        imp_bool($m['done'] ? ($r[$m['done']] ?? null) : null, false) ? 1 : 0,
                        mb_substr(imp_str($m['note'] ? ($r[$m['note']] ?? '') : ''), 0, 2000),
                    ]);
                $counts['agenda']++;
            }
        }

        foreach ($groups['journal'] ?? [] as $g) {
            $m = $g['map'];
            foreach ($g['rows'] as $r) {
                $text = imp_str($m['text'] ? ($r[$m['text']] ?? '') : '') ?: imp_str($m['title'] ? ($r[$m['title']] ?? '') : '');
                if ($text === '') {
                    continue;
                }
                $pdo->prepare('INSERT INTO journal (date, text) VALUES (?,?)')
                    ->execute([imp_date($m['date'] ? ($r[$m['date']] ?? null) : null), mb_substr($text, 0, 2000)]);
                $counts['journal']++;
            }
        }

        if ($dry) {
            $pdo->rollBack();
        } else {
            $pdo->prepare('INSERT INTO imports (source, at, summary) VALUES (?,?,?)')->execute([$source, time(), json_encode($counts)]);
            $pdo->commit();
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
    return ['dry' => $dry, 'counts' => $counts, 'tables' => $report, 'warnings' => $warnings];
}
