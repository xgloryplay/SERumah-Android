<?php
declare(strict_types=1);

const UPLOAD_MAX_BYTES = 10 * 1024 * 1024; // batas aplikasi; batas PHP (upload_max_filesize) juga harus cukup

function upload_asset(?array $file, string $purpose): array
{
    require_master();
    if (!in_array($purpose, ['logo', 'icon'], true)) {
        throw new RuntimeException('Tujuan upload tidak valid');
    }
    $err = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if (in_array($err, [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)) {
        throw new RuntimeException('File lebih besar dari batas server (upload_max_filesize / post_max_size di cPanel)');
    }
    if (!$file || $err !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Tidak ada file yang terunggah. Pilih file lalu coba lagi.');
    }
    if ($file['size'] > UPLOAD_MAX_BYTES) {
        throw new RuntimeException('Ukuran file maksimal 10 MB');
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['png', 'jpg', 'jpeg', 'webp', 'svg'], true)) {
        throw new RuntimeException('Format harus PNG, JPG, WEBP, atau SVG');
    }
    $tmp = $file['tmp_name'];
    if ($ext === 'svg') {
        $svg = (string)file_get_contents($tmp);
        if (!str_contains($svg, '<svg')) {
            throw new RuntimeException('File SVG tidak valid');
        }
        // Tolak SVG yang bisa menjalankan skrip
        if (preg_match('/<script|<foreignObject|javascript:|\bon[a-z]+\s*=/i', $svg)) {
            throw new RuntimeException('SVG mengandung skrip dan ditolak');
        }
    } else {
        $info = @getimagesize($tmp);
        if (!$info || !in_array($info['mime'], ['image/png', 'image/jpeg', 'image/webp'], true)) {
            throw new RuntimeException('Gambar tidak valid');
        }
    }
    $dir = ROOT_DIR . '/assets/uploads';
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
        throw new RuntimeException('Folder upload tidak bisa dibuat');
    }
    $name = $purpose . '-' . bin2hex(random_bytes(6)) . '.' . ($ext === 'jpeg' ? 'jpg' : $ext);
    if (!move_uploaded_file($tmp, $dir . '/' . $name)) {
        throw new RuntimeException('Gagal menyimpan file');
    }
    $url = 'assets/uploads/' . $name;
    db()->prepare('INSERT INTO settings (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v')
        ->execute([$purpose === 'logo' ? 'logo_url' : 'icon_url', $url]);
    return ['url' => $url];
}
