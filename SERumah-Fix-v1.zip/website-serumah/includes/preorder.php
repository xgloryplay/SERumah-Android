<?php
declare(strict_types=1);

const PREORDER_STATUS = ['baru', 'diproses', 'siap', 'selesai', 'batal'];

function preorder_save(array $b): array
{
    $pdo = db();
    $cust = (int)($b['customer_id'] ?? 0);
    if ($cust <= 0) {
        throw new RuntimeException('Pilih pelanggan dulu');
    }
    $needed = (string)($b['needed_date'] ?? '');
    if (!valid_date($needed)) {
        throw new RuntimeException('Tanggal ambil tidak valid');
    }
    $dp = max(0, (int)round((float)($b['dp'] ?? 0)));
    $items = is_array($b['items'] ?? null) ? $b['items'] : [];
    $lines = [];
    $total = 0;
    $prodSt = $pdo->prepare('SELECT id, name, price FROM pos_products WHERE id = ?');
    foreach ($items as $it) {
        $qty = max(0, (int)($it['qty'] ?? 0));
        $pid = (int)($it['product_id'] ?? 0);
        if ($qty <= 0 || $pid <= 0) {
            continue;
        }
        $prodSt->execute([$pid]);
        $p = $prodSt->fetch();
        if (!$p) {
            throw new RuntimeException('Menu tidak ditemukan');
        }
        $lines[] = ['product_id' => $pid, 'name' => $p['name'], 'qty' => $qty, 'price' => (int)$p['price']];
        $total += (int)$p['price'] * $qty;
    }
    if (!$lines) {
        throw new RuntimeException('Tambah minimal satu menu');
    }
    if ($dp > $total) {
        throw new RuntimeException('DP melebihi total');
    }
    $id = (int)($b['id'] ?? 0);
    $note = s($b['note'] ?? '', 2000);
    $pdo->beginTransaction();
    try {
        if ($id > 0) {
            $chk = $pdo->prepare('SELECT stock_done FROM preorders WHERE id = ?');
            $chk->execute([$id]);
            if ($chk->fetchColumn() === false) {
                throw new RuntimeException('Pre order tidak ditemukan');
            }
            $pdo->prepare('UPDATE preorders SET customer_id = ?, needed_date = ?, total = ?, dp = ?, note = ? WHERE id = ?')
                ->execute([$cust, $needed, $total, $dp, $note, $id]);
            $pdo->prepare('DELETE FROM preorder_items WHERE preorder_id = ?')->execute([$id]);
            $no = (int)$pdo->query("SELECT no FROM preorders WHERE id = $id")->fetchColumn();
        } else {
            $no = (int)$pdo->query('SELECT COALESCE(MAX(no), 0) + 1 FROM preorders')->fetchColumn();
            $pdo->prepare('INSERT INTO preorders (no, customer_id, needed_date, total, dp, note, created_at) VALUES (?,?,?,?,?,?,?)')
                ->execute([$no, $cust, $needed, $total, $dp, $note, time()]);
            $id = (int)$pdo->lastInsertId();
        }
        $ins = $pdo->prepare('INSERT INTO preorder_items (preorder_id, product_id, name, qty, price) VALUES (?,?,?,?,?)');
        foreach ($lines as $l) {
            $ins->execute([$id, $l['product_id'], $l['name'], $l['qty'], $l['price']]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return ['id' => $id, 'no' => $no];
}

// Mengubah status. Saat "selesai" pertama kali, stok bahan dikurangi sesuai resep.
function preorder_status(array $b): array
{
    $status = (string)($b['status'] ?? '');
    if (!in_array($status, PREORDER_STATUS, true)) {
        throw new RuntimeException('Status tidak valid');
    }
    $pdo = db();
    $id = (int)($b['id'] ?? 0);
    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare('SELECT * FROM preorders WHERE id = ?');
        $st->execute([$id]);
        $p = $st->fetch();
        if (!$p) {
            throw new RuntimeException('Pre order tidak ditemukan');
        }
        if ($status === 'selesai' && !(int)$p['stock_done']) {
            $need = [];
            $names = [];
            $stock = [];
            $items = $pdo->prepare('SELECT product_id, qty FROM preorder_items WHERE preorder_id = ? AND product_id IS NOT NULL');
            $items->execute([$id]);
            $rec = $pdo->prepare('SELECT r.ingredient_id, r.grams, i.name, i.stock_g FROM pos_recipes r JOIN pos_ingredients i ON i.id = r.ingredient_id WHERE r.product_id = ?');
            foreach ($items->fetchAll() as $it) {
                $rec->execute([$it['product_id']]);
                foreach ($rec->fetchAll() as $r) {
                    $ing = (int)$r['ingredient_id'];
                    $need[$ing] = ($need[$ing] ?? 0) + (float)$r['grams'] * (int)$it['qty'];
                    $names[$ing] = $r['name'];
                    $stock[$ing] = (float)$r['stock_g'];
                }
            }
            foreach ($need as $ing => $g) {
                if ($stock[$ing] < $g) {
                    throw new RuntimeException('Stok ' . $names[$ing] . ' tidak cukup untuk pre order ini');
                }
            }
            foreach ($need as $ing => $g) {
                $pdo->prepare('UPDATE pos_ingredients SET stock_g = stock_g - ? WHERE id = ?')->execute([$g, $ing]);
            }
            $pdo->prepare('UPDATE preorders SET stock_done = 1 WHERE id = ?')->execute([$id]);
        }
        $pdo->prepare('UPDATE preorders SET status = ? WHERE id = ?')->execute([$status, $id]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return ['ok' => true];
}

// Catat pembayaran (DP atau pelunasan) dan masukkan ke wallet bila dipilih.
function preorder_pay(array $b): array
{
    $pdo = db();
    $id = (int)($b['id'] ?? 0);
    $amount = (int)round((float)($b['amount'] ?? 0));
    $wallet = ((int)($b['wallet_id'] ?? 0)) ?: null;
    if ($amount <= 0) {
        throw new RuntimeException('Nominal harus lebih dari 0');
    }
    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare('SELECT * FROM preorders WHERE id = ?');
        $st->execute([$id]);
        $p = $st->fetch();
        if (!$p) {
            throw new RuntimeException('Pre order tidak ditemukan');
        }
        if ($amount > (int)$p['total'] - (int)$p['dp']) {
            throw new RuntimeException('Melebihi sisa bayar');
        }
        $pdo->prepare('UPDATE preorders SET dp = dp + ? WHERE id = ?')->execute([$amount, $id]);
        if ($wallet) {
            $pdo->prepare('INSERT INTO transactions (date, title, amount, type, wallet_id, note, source) VALUES (?,?,?,?,?,?,?)')
                ->execute([date('Y-m-d'), 'Pembayaran pre order #' . $p['no'], $amount, 'in', $wallet, '', 'preorder']);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return ['ok' => true];
}
