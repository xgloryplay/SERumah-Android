<?php
declare(strict_types=1);

const UNIT_GRAM = ['gr' => 1, 'kg' => 1000, 'ml' => 1, 'liter' => 1000];

function pos_sale(array $b): array
{
    $pdo = db();
    $items = $b['items'] ?? [];
    if (!is_array($items) || !$items) {
        throw new RuntimeException('Keranjang kosong');
    }
    $pay = (string)($b['pay'] ?? 'Tunai');
    if (!in_array($pay, ['Tunai', 'QRIS', 'Transfer'], true)) {
        throw new RuntimeException('Metode bayar tidak valid');
    }
    $cash = (int)round((float)($b['cash'] ?? 0));
    $wallet = ((int)($b['wallet_id'] ?? 0)) ?: null;

    $pdo->beginTransaction();
    try {
        $prodSt = $pdo->prepare('SELECT * FROM pos_products WHERE id = ? AND active = 1');
        $recSt = $pdo->prepare('SELECT r.ingredient_id, r.grams, i.name, i.total_g, i.total_cost, i.stock_g FROM pos_recipes r JOIN pos_ingredients i ON i.id = r.ingredient_id WHERE r.product_id = ?');
        $need = [];
        $names = [];
        $lines = [];
        $total = 0;
        $hppTotal = 0;
        foreach ($items as $it) {
            $pid = (int)($it['product_id'] ?? 0);
            $qty = max(0, (int)($it['qty'] ?? 0));
            if ($pid <= 0 || $qty <= 0) {
                continue;
            }
            $prodSt->execute([$pid]);
            $p = $prodSt->fetch();
            if (!$p) {
                throw new RuntimeException('Menu tidak ditemukan atau nonaktif');
            }
            $recSt->execute([$pid]);
            $hpp = 0.0;
            foreach ($recSt->fetchAll() as $r) {
                $ing = (int)$r['ingredient_id'];
                $need[$ing] = ($need[$ing] ?? 0) + $r['grams'] * $qty;
                $names[$ing] = $r['name'];
                $avg = $r['total_g'] > 0 ? $r['total_cost'] / $r['total_g'] : 0;
                $hpp += $avg * $r['grams'];
            }
            $lineHpp = (int)round($hpp * $qty);
            $lines[] = ['product_id' => $pid, 'name' => $p['name'], 'qty' => $qty, 'price' => (int)$p['price'], 'hpp' => $lineHpp];
            $total += (int)$p['price'] * $qty;
            $hppTotal += $lineHpp;
        }
        if (!$lines) {
            throw new RuntimeException('Keranjang kosong');
        }
        $stockSt = $pdo->prepare('SELECT stock_g FROM pos_ingredients WHERE id = ?');
        foreach ($need as $ing => $g) {
            $stockSt->execute([$ing]);
            if ((float)$stockSt->fetchColumn() < $g) {
                throw new RuntimeException('Stok ' . $names[$ing] . ' tidak cukup');
            }
        }
        if ($pay === 'Tunai' && $cash < $total) {
            throw new RuntimeException('Uang diterima kurang dari total');
        }
        foreach ($need as $ing => $g) {
            $pdo->prepare('UPDATE pos_ingredients SET stock_g = stock_g - ? WHERE id = ?')->execute([$g, $ing]);
        }
        $no = (int)$pdo->query("SELECT v FROM settings WHERE k = 'pos_no'")->fetchColumn();
        $pdo->prepare("UPDATE settings SET v = ? WHERE k = 'pos_no'")->execute([(string)($no + 1)]);
        $bayar = $pay === 'Tunai' ? $cash : $total;
        $ts = time();
        $pdo->prepare('INSERT INTO pos_sales (no, ts, total, hpp, pay, cash, wallet_id) VALUES (?,?,?,?,?,?,?)')
            ->execute([$no, $ts, $total, $hppTotal, $pay, $bayar, $wallet]);
        $sid = (int)$pdo->lastInsertId();
        $itemSt = $pdo->prepare('INSERT INTO pos_sale_items (sale_id, product_id, name, qty, price, hpp) VALUES (?,?,?,?,?,?)');
        foreach ($lines as $l) {
            $itemSt->execute([$sid, $l['product_id'], $l['name'], $l['qty'], $l['price'], $l['hpp']]);
        }
        if ($wallet) {
            $cat = $pdo->query("SELECT id FROM categories WHERE name = 'Penjualan POS' LIMIT 1")->fetchColumn() ?: null;
            $pdo->prepare('INSERT INTO transactions (date, title, amount, type, wallet_id, category_id, note, source) VALUES (?,?,?,?,?,?,?,?)')
                ->execute([date('Y-m-d', $ts), 'Penjualan POS #' . $no, $total, 'in', $wallet, $cat, '', 'pos']);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return ['sale_id' => $sid, 'no' => $no, 'total' => $total, 'hpp' => $hppTotal, 'pay' => $pay, 'bayar' => $bayar, 'ts' => $ts, 'items' => $lines];
}

function pos_purchase(array $b): array
{
    $pdo = db();
    $unit = (string)($b['unit'] ?? 'gr');
    if (!isset(UNIT_GRAM[$unit])) {
        throw new RuntimeException('Satuan tidak valid');
    }
    $qty = (float)($b['qty'] ?? 0);
    $cost = (int)round((float)($b['cost'] ?? 0));
    $date = (string)($b['date'] ?? date('Y-m-d'));
    $wallet = ((int)($b['wallet_id'] ?? 0)) ?: null;
    if ($qty <= 0) {
        throw new RuntimeException('Jumlah harus lebih dari 0');
    }
    if (!valid_date($date)) {
        throw new RuntimeException('Tanggal tidak valid');
    }
    $grams = $qty * UNIT_GRAM[$unit];
    $pdo->beginTransaction();
    try {
        $iid = (int)($b['ingredient_id'] ?? 0);
        if ($iid <= 0) {
            $name = s($b['new_name'] ?? '', 120);
            if ($name === '') {
                throw new RuntimeException('Pilih bahan atau isi nama bahan baru');
            }
            $pdo->prepare('INSERT INTO pos_ingredients (name) VALUES (?)')->execute([$name]);
            $iid = (int)$pdo->lastInsertId();
        }
        $nameSt = $pdo->prepare('SELECT name FROM pos_ingredients WHERE id = ?');
        $nameSt->execute([$iid]);
        $iname = (string)$nameSt->fetchColumn();
        if ($iname === '') {
            throw new RuntimeException('Bahan tidak ditemukan');
        }
        $pdo->prepare('UPDATE pos_ingredients SET total_g = total_g + ?, total_cost = total_cost + ?, stock_g = stock_g + ? WHERE id = ?')
            ->execute([$grams, $cost, $grams, $iid]);
        $pdo->prepare('INSERT INTO pos_purchases (date, ingredient_id, grams, cost) VALUES (?,?,?,?)')->execute([$date, $iid, $grams, $cost]);
        if ($wallet) {
            $cat = $pdo->query("SELECT id FROM categories WHERE name = 'Belanja bahan' LIMIT 1")->fetchColumn() ?: null;
            $pdo->prepare('INSERT INTO transactions (date, title, amount, type, wallet_id, category_id, note, source) VALUES (?,?,?,?,?,?,?,?)')
                ->execute([$date, 'Beli bahan: ' . $iname, $cost, 'out', $wallet, $cat, '', 'pos']);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return ['ok' => true];
}

function pos_recipe(array $b): array
{
    $pdo = db();
    $pid = (int)($b['product_id'] ?? 0);
    $items = is_array($b['items'] ?? null) ? $b['items'] : [];
    $pdo->beginTransaction();
    try {
        $pdo->prepare('DELETE FROM pos_recipes WHERE product_id = ?')->execute([$pid]);
        $st = $pdo->prepare('INSERT INTO pos_recipes (product_id, ingredient_id, grams) VALUES (?,?,?)');
        foreach ($items as $it) {
            $g = (float)($it['grams'] ?? 0);
            $iid = (int)($it['ingredient_id'] ?? 0);
            if ($g > 0 && $iid > 0) {
                $st->execute([$pid, $iid, $g]);
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return ['ok' => true];
}
