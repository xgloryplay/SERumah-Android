<?php
declare(strict_types=1);

// Whitelist entitas. Tipe: s=string, n=catatan, i=integer, f=float, b=boolean, k=foreign key, d=tanggal, e:a|b=enum
const ENTITIES = [
    'wallets' => ['table' => 'wallets', 'req' => ['name'], 'cols' => ['name' => 's', 'type' => 'e:tunai|bank|ewallet|emoney|lainnya', 'start_balance' => 'i', 'color' => 's', 'archived' => 'b', 'card_uid' => 's']],
    'categories' => ['table' => 'categories', 'req' => ['name'], 'cols' => ['name' => 's', 'kind' => 'e:in|out|both', 'budget' => 'i', 'color' => 's', 'alloc_pct' => 'i']],
    'transactions' => ['table' => 'transactions', 'req' => ['date', 'title', 'amount', 'type'], 'cols' => ['date' => 'd', 'title' => 's', 'amount' => 'i', 'type' => 'e:in|out|transfer', 'wallet_id' => 'k', 'to_wallet_id' => 'k', 'category_id' => 'k', 'note' => 'n']],
    'recurring' => ['table' => 'recurring', 'req' => ['title', 'amount', 'next_date'], 'cols' => ['title' => 's', 'amount' => 'i', 'type' => 'e:in|out', 'wallet_id' => 'k', 'category_id' => 'k', 'frequency' => 'e:weekly|monthly', 'next_date' => 'd', 'active' => 'b']],
    'debts' => ['table' => 'debts', 'req' => ['party', 'amount'], 'cols' => ['kind' => 'e:utang|piutang', 'party' => 's', 'amount' => 'i', 'due_date' => 'd', 'note' => 'n']],
    'goals' => ['table' => 'goals', 'req' => ['name', 'target'], 'cols' => ['name' => 's', 'target' => 'i', 'due_date' => 'd', 'color' => 's']],
    'assets' => ['table' => 'assets', 'req' => ['name'], 'cols' => ['name' => 's', 'type' => 'e:saham|reksadana|emas|properti|kendaraan|lainnya', 'qty' => 'f', 'buy_price' => 'i', 'current_price' => 'i', 'date_bought' => 'd', 'note' => 'n']],
    'agenda' => ['table' => 'agenda', 'req' => ['date', 'title'], 'cols' => ['date' => 'd', 'title' => 's', 'category' => 's', 'kind' => 'e:tugas|tagihan', 'amount' => 'i', 'done' => 'b', 'note' => 'n', 'time' => 't']],
    'customers' => ['table' => 'customers', 'req' => ['name'], 'cols' => ['name' => 's', 'phone' => 's', 'address' => 's', 'note' => 'n']],
    'preorders' => ['table' => 'preorders', 'req' => ['needed_date'], 'cols' => ['customer_id' => 'k', 'needed_date' => 'd', 'status' => 'e:baru|diproses|siap|selesai|batal', 'dp' => 'i', 'note' => 'n']],
    'journal' => ['table' => 'journal', 'req' => ['date', 'text'], 'cols' => ['date' => 'd', 'text' => 'n']],
    'pos_products' => ['table' => 'pos_products', 'req' => ['name', 'price'], 'cols' => ['name' => 's', 'price' => 'i', 'active' => 'b']],
];

function coerce(string $kind, $v)
{
    if (str_starts_with($kind, 'e:')) {
        $allowed = explode('|', substr($kind, 2));
        $val = (string)$v;
        if (!in_array($val, $allowed, true)) {
            json_out(['error' => 'Nilai tidak valid: ' . $val], 422);
        }
        return $val;
    }
    switch ($kind) {
        case 's': return s($v, 200);
        case 'n': return s($v, 2000);
        case 'i': return (int)round((float)$v);
        case 'f': return (float)$v;
        case 'b': return ($v === true || $v === 1 || $v === '1' || $v === 'on') ? 1 : 0;
        case 'k': $i = (int)$v; return $i > 0 ? $i : null;
        case 't': $t = (string)$v; return preg_match('/^\d{2}:\d{2}$/', $t) ? $t : null;
        case 'd':
            if ($v === null || $v === '') {
                return null;
            }
            if (!valid_date($v)) {
                json_out(['error' => 'Format tanggal tidak valid'], 422);
            }
            return (string)$v;
    }
    return null;
}

function crud_save(string $entity, array $data): int
{
    if (!isset(ENTITIES[$entity])) {
        json_out(['error' => 'Entitas tidak dikenal'], 404);
    }
    $def = ENTITIES[$entity];
    $id = (int)($data['id'] ?? 0);
    $row = [];
    foreach ($def['cols'] as $col => $kind) {
        if (array_key_exists($col, $data)) {
            $row[$col] = coerce($kind, $data[$col]);
        }
    }
    foreach ($def['req'] as $col) {
        if (($id === 0 || array_key_exists($col, $row)) && (!isset($row[$col]) || $row[$col] === '')) {
            json_out(['error' => 'Kolom ' . $col . ' wajib diisi'], 422);
        }
    }
    $pdo = db();
    if ($id > 0) {
        if (!$row) {
            return $id;
        }
        $sets = implode(', ', array_map(fn($c) => "$c = :$c", array_keys($row)));
        $row['_id'] = $id;
        $pdo->prepare("UPDATE {$def['table']} SET $sets WHERE id = :_id")->execute($row);
        return $id;
    }
    $cols = implode(', ', array_keys($row));
    $ph = implode(', ', array_map(fn($c) => ":$c", array_keys($row)));
    $pdo->prepare("INSERT INTO {$def['table']} ($cols) VALUES ($ph)")->execute($row);
    return (int)$pdo->lastInsertId();
}

function crud_delete(string $entity, int $id): void
{
    if (!isset(ENTITIES[$entity])) {
        json_out(['error' => 'Entitas tidak dikenal'], 404);
    }
    db()->prepare('DELETE FROM ' . ENTITIES[$entity]['table'] . ' WHERE id = ?')->execute([$id]);
}
