<?php
declare(strict_types=1);

const USER_ROLES = ['admin', 'user'];

// Tambah atau perbarui akun berdasarkan username. Hanya master.
function user_save(array $b): array
{
    require_master('Hanya akun master yang bisa mengelola akun');
    $pdo = db();
    $username = strtolower(s($b['username'] ?? '', 60));
    if (!preg_match('/^[a-z0-9._-]{3,60}$/', $username)) {
        throw new RuntimeException('Username 3-60 karakter: huruf kecil, angka, titik, strip, atau garis bawah');
    }
    if ($username === 'master') {
        throw new RuntimeException('Username master dikunci');
    }
    $role = (string)($b['role'] ?? 'user');
    if (!in_array($role, USER_ROLES, true)) {
        throw new RuntimeException('Peran tidak valid');
    }
    $name = s($b['name'] ?? '', 80);
    $pw = (string)($b['password'] ?? '');
    if ($pw !== '' && strlen($pw) < 8) {
        throw new RuntimeException('Password minimal 8 karakter');
    }
    $st = $pdo->prepare('SELECT id FROM users WHERE username = ?');
    $st->execute([$username]);
    $id = (int)$st->fetchColumn();
    if ($id) {
        $pdo->prepare('UPDATE users SET name = ?, role = ? WHERE id = ?')->execute([$name, $role, $id]);
        if ($pw !== '') {
            $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($pw, PASSWORD_DEFAULT), $id]);
        }
        return ['id' => $id, 'created' => false];
    }
    if ($pw === '') {
        throw new RuntimeException('Password wajib untuk akun baru');
    }
    $pdo->prepare('INSERT INTO users (username, password_hash, name, role) VALUES (?,?,?,?)')
        ->execute([$username, password_hash($pw, PASSWORD_DEFAULT), $name, $role]);
    return ['id' => (int)$pdo->lastInsertId(), 'created' => true];
}

function users_list(): array
{
    if (current_role() !== 'master') {
        return [];
    }
    return db()->query('SELECT id, username, name, role FROM users ORDER BY id')->fetchAll();
}
