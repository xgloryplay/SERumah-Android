<?php
declare(strict_types=1);

require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/entities.php';
require __DIR__ . '/includes/auth.php';
require __DIR__ . '/includes/finance.php';
require __DIR__ . '/includes/pos.php';
require __DIR__ . '/includes/weather.php';
require __DIR__ . '/includes/import.php';
require __DIR__ . '/includes/upload.php';
require __DIR__ . '/includes/preorder.php';
require __DIR__ . '/includes/users.php';

send_security_headers();
start_session();

$action = (string)($_GET['a'] ?? '');
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($action) {
        case 'auth.me':
            json_out([
                'auth' => !empty($_SESSION['uid']),
                'csrf' => csrf_token(),
                'user' => !empty($_SESSION['uid']) ? current_user() : null,
            ]);
            break;

        case 'auth.login':
            post_only($method);
            require_csrf();
            $res = login_user(body_json());
            json_out($res + ['csrf' => rotate_csrf()]);
            break;

        case 'auth.logout':
            post_only($method);
            require_login();
            require_csrf();
            logout_user();
            json_out(['ok' => true]);
            break;

        case 'auth.password':
            post_only($method);
            require_login();
            require_csrf();
            change_password(body_json());
            json_out(['ok' => true]);
            break;

        case 'data.all':
            require_login();
            run_recurring();
            json_out(bundle());
            break;

        case 'crud.save':
            post_only($method);
            require_login();
            require_csrf();
            $b = body_json();
            json_out(['id' => crud_save((string)($b['entity'] ?? ''), (array)($b['data'] ?? []))]);
            break;

        case 'crud.delete':
            post_only($method);
            require_login();
            require_csrf();
            $b = body_json();
            crud_delete((string)($b['entity'] ?? ''), (int)($b['id'] ?? 0));
            json_out(['ok' => true]);
            break;

        case 'debt.pay':
            post_only($method);
            require_login();
            require_csrf();
            json_out(debt_pay(body_json()));
            break;

        case 'goal.add':
            post_only($method);
            require_login();
            require_csrf();
            json_out(goal_add(body_json()));
            break;

        case 'settings.save':
            post_only($method);
            require_login();
            require_csrf();
            json_out(settings_save(body_json()));
            break;

        case 'pos.sale':
            post_only($method);
            require_login();
            require_csrf();
            json_out(pos_sale(body_json()));
            break;

        case 'pos.purchase':
            post_only($method);
            require_login();
            require_csrf();
            json_out(pos_purchase(body_json()));
            break;

        case 'pos.recipe':
            post_only($method);
            require_login();
            require_csrf();
            json_out(pos_recipe(body_json()));
            break;

        case 'preorder.pay':
            post_only($method);
            require_login();
            require_csrf();
            json_out(preorder_pay(body_json()));
            break;

        case 'user.save':
            post_only($method);
            require_login();
            require_csrf();
            json_out(user_save(body_json()));
            break;

        case 'weather':
            require_login();
            if (isset($_GET['lat'], $_GET['lon']) && is_numeric($_GET['lat']) && is_numeric($_GET['lon'])) {
                $lat = (float)$_GET['lat'];
                $lon = (float)$_GET['lon'];
                if (abs($lat) > 90 || abs($lon) > 180) {
                    json_out(['error' => 'Koordinat tidak valid'], 422);
                }
                json_out(['name' => 'Lokasi saya', 'data' => weather_at($lat, $lon)]);
            }
            json_out(weather_for_settings());
            break;

        case 'upload':
            post_only($method);
            require_login();
            require_csrf();
            json_out(upload_asset($_FILES['file'] ?? null, (string)($_POST['purpose'] ?? '')));
            break;

        case 'preorder.save':
            post_only($method);
            require_login();
            require_csrf();
            json_out(preorder_save(body_json()));
            break;

        case 'preorder.status':
            post_only($method);
            require_login();
            require_csrf();
            json_out(preorder_status(body_json()));
            break;

        case 'geocode':
            require_login();
            json_out(geocode((string)($_GET['q'] ?? '')));
            break;

        case 'import':
            post_only($method);
            require_login();
            require_csrf();
            json_out(import_upload($_FILES['file'] ?? null, (string)($_POST['dry'] ?? '1')));
            break;

        default:
            json_out(['error' => 'Endpoint tidak ditemukan'], 404);
    }
} catch (RuntimeException $e) {
    json_out(['error' => $e->getMessage()], 422);
} catch (Throwable $e) {
    error_log('[serumah] ' . $e->getMessage());
    json_out(['error' => 'Terjadi kesalahan pada server'], 500);
}
