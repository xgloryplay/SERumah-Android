#!/usr/bin/env python3
"""Add the Android permissions used by SERumah's free Capacitor plugins."""
import sys
from pathlib import Path
import xml.etree.ElementTree as ET

path = Path(sys.argv[1])
ET.register_namespace("android", "http://schemas.android.com/apk/res/android")
ANDROID = "{http://schemas.android.com/apk/res/android}"
tree = ET.parse(path)
root = tree.getroot()
permissions = [
    "android.permission.ACCESS_COARSE_LOCATION",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.READ_CALENDAR",
    "android.permission.WRITE_CALENDAR",
    "android.permission.NFC",
]
existing = {node.get(ANDROID + "name") for node in root.findall("uses-permission")}
for name in permissions:
    if name not in existing:
        node = ET.Element("uses-permission")
        node.set(ANDROID + "name", name)
        root.insert(0, node)
features = root.findall("uses-feature")
feature = next((x for x in features if x.get(ANDROID + "name") == "android.hardware.nfc"), None)
if feature is None:
    feature = ET.Element("uses-feature")
    feature.set(ANDROID + "name", "android.hardware.nfc")
    root.insert(0, feature)
feature.set(ANDROID + "required", "false")
tree.write(path, encoding="utf-8", xml_declaration=True)
print("SERumah Android permissions configured.")
