# SERumah Android

Capacitor 6 wrapper for the SERumah web application.

## Free native plugins
- Camera, Geolocation, Local Notifications
- Calendar: @ebarooni/capacitor-calendar (native calendar events)
- NFC: @capgo/capacitor-nfc (tag detection/UID only)

NFC UID detection is not a balance reader. Mandiri e-money, Flazz, and TapCash balance access is not implemented.

## Build
GitHub Actions builds a debug APK on push to main or manual workflow dispatch.
